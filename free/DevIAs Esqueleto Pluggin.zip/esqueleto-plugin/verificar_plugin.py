"""VERIFICAR, SUBIR VERSIÓN Y EMPAQUETAR UN PLUGIN (DevIAs Panel).
    python esqueleto-plugin/verificar_plugin.py ID_O_RUTA [--zip] [--subir patch|minor|major --nota "qué cambió"]
Hace, en este orden (sale con código 1 si algo obligatorio falla):
  1. Verificador OFICIAL del panel (/api/plugin_verificar): el mismo que decide si el plugin se puede instalar y usar.
  2. Revisión propia: marcadores sin rellenar ({{…}} y ‹…›), versión x.y.z, archivos de voz/mezcla/render prohibidos, claves o rutas personales, .py compilan,
     cada ficha de specs/ se construye en CADA formato del plugin y el game.js resultante tiene sintaxis válida (node --check, si hay node).
  3. --subir: sube la versión en plugin.json y anota la línea en memoria.md (--nota es obligatoria).
  4. --zip: crea PLUGIN-vX.Y.Z.zip junto a la carpeta del plugin (con la carpeta del plugin en la raíz del zip, como lo espera el instalador del panel).
Úsalo SIEMPRE antes de entregar un plugin y después de cada mejora."""
import sys, re, json, shutil, pathlib, subprocess, tempfile, time, zipfile, urllib.request, os
AQUI = pathlib.Path(__file__).resolve().parent; PANEL = AQUI.parent
a = [x for x in sys.argv[1:] if not x.startswith("--")]
if not a: sys.exit(__doc__)
D = pathlib.Path(a[0]) if (pathlib.Path(a[0]).is_dir()) else PANEL / "plugins" / a[0]
if not (D / "plugin.json").is_file(): sys.exit("No encuentro %s/plugin.json" % D)
M = json.loads((D / "plugin.json").read_text(encoding="utf-8")); PID = M.get("id", D.name); fallos, avisos = [], []
def ok(t): print("  ✔ " + t)
def mal(t): print("  ✘ " + t); fallos.append(t)
def aviso(t): print("  • " + t); avisos.append(t)
# ---- 3. subir versión (antes de verificar y empaquetar) ----
if "--subir" in sys.argv:
    nivel = sys.argv[sys.argv.index("--subir") + 1]; nota = sys.argv[sys.argv.index("--nota") + 1] if "--nota" in sys.argv else ""
    if nivel not in ("patch", "minor", "major") or not nota: sys.exit("--subir patch|minor|major exige --nota \"qué cambió\"")
    x, y, z = [int(v) for v in M["version"].split(".")]; nv = {"patch": (x, y, z + 1), "minor": (x, y + 1, 0), "major": (x + 1, 0, 0)}[nivel]; vieja = M["version"]; M["version"] = "%d.%d.%d" % nv
    (D / "plugin.json").write_text(json.dumps(M, ensure_ascii=False, indent=1), encoding="utf-8")
    mem = D / "memoria.md"; t = mem.read_text(encoding="utf-8") if mem.exists() else "# memoria\n\n## Versiones\n"
    linea = "- %s (%s): %s\n" % (M["version"], time.strftime("%Y-%m-%d"), nota); t = t.replace("## Versiones\n", "## Versiones\n" + linea, 1) if "## Versiones\n" in t else t + "\n## Versiones\n" + linea
    mem.write_text(t, encoding="utf-8"); print("Versión %s → %s anotada en memoria.md" % (vieja, M["version"]))
print("\n== %s v%s ==" % (PID, M.get("version")))
# ---- 1. verificador oficial ----
print("1. Verificador del panel")
try:
    r = json.loads(urllib.request.urlopen("http://localhost:8820/api/plugin_verificar?id=" + D.name, timeout=10).read().decode("utf-8"))
    bad = [c for c in r.get("checks", []) if not c["ok"]]
    if not bad: ok("%d comprobaciones" % len(r.get("checks", [])))
    for c in bad: mal("%s: %s" % (c["grupo"], c["texto"]))
except Exception as e: aviso("el panel no respondió (puerto 8820): no se pudo correr el verificador oficial — enciéndelo y repite")
# ---- 2. revisión propia ----
print("2. Revisión propia")
if not re.fullmatch(r"\d+\.\d+\.\d+", str(M.get("version", ""))): mal("version debe ser x.y.z (ahora: %s)" % M.get("version"))
else: ok("versión %s" % M["version"])
texto = [f for f in D.rglob("*") if f.is_file() and f.suffix in (".json", ".md", ".js", ".py", ".html", ".txt") and "__pycache__" not in f.parts]
pend = [str(f.relative_to(D)) for f in texto if re.search(r"\{\{[A-Z]+\}\}|‹", f.read_text(encoding="utf-8", errors="ignore"))]
(aviso("marcadores sin rellenar (‹…› o {{…}}) en: " + ", ".join(pend[:6]) + ("…" if len(pend) > 6 else "")) if pend else ok("no quedan marcadores sin rellenar"))
prohibidos = [str(f.relative_to(D)) for f in D.rglob("*.py") if re.fullmatch(r"(unir|mix|mix_escena|mix_short|mezcla|grab|grabar|grab_fast|grab_gpu|grab_paralelo|grabar_rapido|regrabar_tramo|generar_voz_api|rehacer_frase|musica_fondo|voz_[a-z_]+)\.py", f.name)]
(mal("el plugin trae su propio motor de voz/mezcla/render: " + ", ".join(prohibidos)) if prohibidos else ok("no trae voz, mezcla ni render propios (son del panel)"))
sec = [str(f.relative_to(D)) for f in texto if re.search(r"(?i)(api[_-]?key|secret|token|password|contrase|hf_[A-Za-z0-9]{20,}|sk-[A-Za-z0-9]{20,})\s*[:=]\s*[\"'][^\"']{8,}", f.read_text(encoding="utf-8", errors="ignore")) or re.search(r"[A-Za-z]:\\\\?(Users|Usuarios)\\\\", f.read_text(encoding="utf-8", errors="ignore"))]
(mal("posibles claves o rutas personales en: " + ", ".join(sec)) if sec else ok("sin claves ni rutas personales"))
malos_py = []
for f in D.rglob("*.py"):
    if "__pycache__" in f.parts: continue
    try: compile(f.read_text(encoding="utf-8"), str(f), "exec")   # compila en memoria: no deja .pyc ni toca el disco
    except SyntaxError as e: malos_py.append("%s no compila (línea %s): %s" % (f.relative_to(D), e.lineno, str(e.msg)[:80]))
for x in malos_py: mal(x)
if not malos_py: ok("los .py compilan")
cons = sorted(D.glob("motor_*/construir.py")); node = shutil.which("node")
if not cons: aviso("no hay motor_*/construir.py: no se pudo probar la construcción")
else:
    for sp in sorted((D / "specs").glob("*.json")):
        for fm in M.get("formatos", []):
            tmp = pathlib.Path(tempfile.mkdtemp(prefix="vp_")); r = subprocess.run([sys.executable, "-X", "utf8", str(cons[0]), str(sp), "vp_" + sp.stem, "--formato", fm, "--carpeta", str(tmp)], capture_output=True, text=True, encoding="utf-8", cwd=str(PANEL))
            if r.returncode != 0:
                if "usar --formato" in (r.stdout + r.stderr) or "formato" in (r.stdout + r.stderr).lower() and "vertical" in (r.stdout + r.stderr).lower(): aviso("%s no aplica al formato %s" % (sp.name, fm))
                else: mal("la ficha %s no construye en %s: %s" % (sp.name, fm, (r.stdout + r.stderr).strip().splitlines()[-1][:160] if (r.stdout + r.stderr).strip() else "?"))
            else:
                g = tmp / "game.js"
                if node and g.is_file():
                    nr = subprocess.run([node, "--check", str(g)], capture_output=True, text=True); (ok("%s · %s: construye y game.js tiene sintaxis válida" % (sp.name, fm)) if nr.returncode == 0 else mal("game.js de %s · %s: %s" % (sp.name, fm, nr.stderr.strip()[:200])))
                else: ok("%s · %s: construye%s" % (sp.name, fm, "" if node else " (sin node: no se revisó la sintaxis de game.js)"))
            shutil.rmtree(tmp, ignore_errors=True)
# ---- 4. zip ----
if "--zip" in sys.argv:
    if fallos: print("\nNo se empaqueta: hay fallos.");
    else:
        z = D.parent / ("%s-v%s.zip" % (PID, M["version"]))
        with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in sorted(D.rglob("*")):
                if f.is_file() and "__pycache__" not in f.parts and f.suffix != ".zip": zf.write(f, (pathlib.Path(D.name) / f.relative_to(D)).as_posix())
        print("\n✔ zip listo: %s (%d KB). Instálalo desde la pestaña Plugins del panel." % (z, z.stat().st_size // 1024))
print("\n%s — %d fallo(s), %d aviso(s)" % ("✘ NO LISTO" if fallos else "✔ LISTO", len(fallos), len(avisos)))
sys.exit(1 if fallos else 0)
