"""CREAR UN PLUGIN NUEVO A PARTIR DEL ESQUELETO (DevIAs Panel).
    python esqueleto-plugin/crear_plugin.py ID "Nombre visible" [--destino CARPETA_PLUGINS] [--sin-prueba]
  ID       identificador del plugin = nombre de su carpeta: minúsculas, números y guiones (ej.: «cocina-rapida»)
  Nombre   cómo lo verá el usuario en la pestaña Plugins
Qué hace: copia esqueleto-plugin/plantilla/ a plugins/ID/, cambia los marcadores ({{ID}}, {{NOMBRE}}, {{MOD}}, {{FECHA}} y PLUGIN en los nombres de archivo), la verifica con el panel
(si está encendido) y construye el video de ejemplo para que veas que funciona de punta a punta. El plugin que sale YA PASA el verificador: ahora sustituye la demostración por tu estilo real
y sigue GUIA_CREAR_Y_MEJORAR_PLUGIN.md. Este esqueleto en sí NO es un plugin y no se instala (no tiene plugin.json y vive fuera de plugins/)."""
import sys, re, json, shutil, pathlib, subprocess, time, urllib.request
AQUI = pathlib.Path(__file__).resolve().parent; PANEL = AQUI.parent; PLANTILLA = AQUI / "plantilla"; TEXTO = {".json", ".md", ".js", ".py", ".html", ".txt"}
def sal(m): sys.exit("NO SE CREA: " + m)
a = [x for x in sys.argv[1:] if not x.startswith("--")]
if len(a) < 2: sys.exit(__doc__)
PID, NOMBRE = a[0].strip(), a[1].strip()
if not re.fullmatch(r"[a-z0-9][a-z0-9\-]{1,60}", PID): sal("el id «%s» no es válido: usa minúsculas, números y guiones (2 a 61 caracteres), sin espacios ni tildes" % PID)
if not NOMBRE or re.search(r'["\\\n]', NOMBRE): sal("el nombre visible no puede estar vacío ni llevar comillas dobles, barras invertidas o saltos de línea")
DEST = pathlib.Path(sys.argv[sys.argv.index("--destino") + 1]) if "--destino" in sys.argv else PANEL / "plugins"
OUT = DEST / PID
if OUT.exists(): sal("ya existe %s (elige otro id, o borra/renombra esa carpeta)" % OUT)
if not PLANTILLA.is_dir(): sal("no encuentro la plantilla en %s" % PLANTILLA)
MOD = PID.replace("-", "_"); FECHA = time.strftime("%Y-%m-%d")
def marca(s): return s.replace("{{ID}}", PID).replace("{{NOMBRE}}", NOMBRE).replace("{{MOD}}", MOD).replace("{{FECHA}}", FECHA)
n = 0
for f in sorted(PLANTILLA.rglob("*")):
    if "__pycache__" in f.parts: continue
    rel = f.relative_to(PLANTILLA); partes = ["plugin.json" if p == "plugin.plantilla.json" else p.replace("PLUGIN", MOD) for p in rel.parts]; dst = OUT.joinpath(*partes)
    if f.is_dir(): dst.mkdir(parents=True, exist_ok=True); continue
    dst.parent.mkdir(parents=True, exist_ok=True)
    if f.suffix in TEXTO: dst.write_text(marca(f.read_text(encoding="utf-8")), encoding="utf-8")
    else: shutil.copy2(f, dst)
    n += 1
json.loads((OUT / "plugin.json").read_text(encoding="utf-8"))   # si algo quedó mal escapado, falla aquí
print("✔ plugin «%s» creado en %s (%d archivos)" % (PID, OUT, n))
# ---- verificación con el panel (si está encendido) ----
ok_api = None
try:
    r = json.loads(urllib.request.urlopen("http://localhost:8820/api/plugin_verificar?id=" + PID, timeout=8).read().decode("utf-8")); ok_api = r.get("ok")
    mal = [c["texto"] for c in r.get("checks", []) if not c["ok"]]
    print("%s verificador del panel: %d comprobaciones%s" % ("✔" if ok_api else "✘", len(r.get("checks", [])), "" if ok_api else " · fallan: " + "; ".join(mal[:5])))
except Exception as e: print("• el panel no respondió (¿está encendido en el puerto 8820?). Cuando lo esté: python esqueleto-plugin/verificar_plugin.py %s" % PID)
# ---- video de ejemplo ----
if "--sin-prueba" not in sys.argv and DEST.resolve() == (PANEL / "plugins").resolve():
    c = OUT / ("motor_" + MOD) / "construir.py"; pid_p = "zz_%s_prueba" % MOD
    r = subprocess.run([sys.executable, "-X", "utf8", str(c), str(OUT / "specs" / "ejemplo.json"), pid_p], capture_output=True, text=True, encoding="utf-8", cwd=str(PANEL))
    print(("✔ video de ejemplo construido: http://localhost:8820/series/%s/index.html?play=1  (bórralo cuando termines: series/%s)" % (pid_p, pid_p)) if r.returncode == 0 else "✘ el ejemplo no se construyó:\n" + (r.stdout + r.stderr).strip()[-600:])
print("\nSiguiente: 1) abre GUIA_CREAR_Y_MEJORAR_PLUGIN.md  2) rellena INSTRUCCIONES.md, DISENO.md y NO_HACER.md  3) cambia motor/motor.js por tu estilo  4) verifica con verificar_plugin.py  5) empaqueta con --zip")
print("IMPORTANTE (Windows): no dejes tu terminal con la carpeta del plugin como carpeta actual; usa rutas absolutas.")
