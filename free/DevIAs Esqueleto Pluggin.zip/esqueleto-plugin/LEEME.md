# Esqueleto de plugins del DevIAs Panel

**Esto NO es un plugin y NO se instala.** Es la base para construir plugins nuevos (y la guía para crearlos y mejorarlos). No tiene `plugin.json` (tiene `plugin.plantilla.json`) y vive fuera de `plugins/`, así que el panel nunca lo detecta ni lo puede instalar.

## Qué hay
| Archivo | Para qué |
|---|---|
| **`GUIA_CREAR_Y_MEJORAR_PLUGIN.md`** | La guía completa: anatomía, contratos, cómo crear, cómo mejorar, checklist, errores típicos, lecciones |
| `crear_plugin.py` | Genera `plugins/<id>/` desde la plantilla (ya válido) y construye un video de ejemplo |
| `verificar_plugin.py` | Verifica (panel + revisión propia), sube la versión (`--subir`) y empaqueta el zip (`--zip`) |
| `plantilla/` | El plugin de demostración con marcadores `{{ID}}`, `{{NOMBRE}}`, `{{MOD}}`, `{{FECHA}}` y `PLUGIN` en nombres de archivo |

## Uso en 3 comandos (con el panel encendido, desde la carpeta del panel)
```powershell
python esqueleto-plugin/crear_plugin.py mi-plugin "Mi plugin"
python esqueleto-plugin/verificar_plugin.py mi-plugin
python esqueleto-plugin/verificar_plugin.py mi-plugin --zip
```
Después de crearlo: rellena los `.md` (todo lo que está entre `‹ ›`), cambia `motor/motor.js` por tu estilo real y vuelve a verificar. Sigue la guía.

> Windows: no dejes tu terminal con la carpeta de un plugin como carpeta actual (impide que el panel lo mueva y lo deja vacío). Usa rutas absolutas.
