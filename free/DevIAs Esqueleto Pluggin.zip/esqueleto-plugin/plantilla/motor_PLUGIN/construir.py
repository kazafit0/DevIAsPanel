"""CONSTRUCTOR del plugin «{{ID}}» (DevIAs Panel). Convierte la FICHA (spec .json) de un video en un PROYECTO listo para el panel:
    python construir.py SPEC.json ID_DEL_VIDEO [--formato short|largo] [--carpeta RUTA_DE_SALIDA]
Crea series/ID/ con: index.html, game_head.js, game_body.js (la ficha), game_tail.js, game.js (todo junto), proyecto.json y guion/1.json (+ _original).
Si la ficha NO cumple las reglas, NO construye y dice qué corregir (así Claude no entrega algo roto).
Reglas de esta plantilla (cámbialas por las de tu plugin, pero deja siempre una comprobación del tiempo y del cierre):
  ≥ 3 tomas · claves únicas · tipo de toma conocido · una idea por frase (≤ 26 palabras) · el cierre es una frase COMPLETA ·
  el tiempo estimado está entre el 75 % y el 104 % de la duración pedida (spec.seg).
Ficha: {"titulo", "seg", "formato", "seo": {...}, "ajustes": {...}, "escenas": [{"key": "e01", "texto": "…frase…", "tipo": "tarjeta", "titulo": "…", "paleta": ["#hex", "#hex"]}]}"""
import sys, os, json, re, pathlib
HERE = pathlib.Path(__file__).resolve().parent; PLUG = HERE.parent; ROOT = PLUG.parent.parent   # PLUG = carpeta del plugin · ROOT = carpeta del DevIAs Panel
TIPOS = ("tarjeta",)   # tipos de toma que dibuja motor/motor.js (MOTOR.tipos)
RITMO = 0.0775; PAUSA = 0.25   # s por carácter (el MISMO ritmo con que el panel estima el borrador) y pausa entre frases
def sal(m): sys.exit("NO SE CONSTRUYE: " + m)
a = [x for x in sys.argv[1:] if not x.startswith("--")]
if len(a) < 2: sys.exit(__doc__)
SPEC = json.loads(pathlib.Path(a[0]).read_text(encoding="utf-8")); PID = a[1]
FORMATO = (sys.argv[sys.argv.index("--formato") + 1] if "--formato" in sys.argv else SPEC.get("formato", "short")); assert FORMATO in ("short", "largo"), "formato: short o largo"
SAL = pathlib.Path(sys.argv[sys.argv.index("--carpeta") + 1]) if "--carpeta" in sys.argv else ROOT / "series" / PID
W, H = (1920, 1080) if FORMATO == "largo" else (1080, 1920)
AJ = json.loads(os.environ.get("PLUGIN_AJUSTES") or "{}")   # ajustes del plugin (pestaña Plugins → Configurar): el panel los pasa en esta variable de entorno
for k in ("subtitulos", "intensidad", "estilo_fondo"):
    if k in AJ: SPEC.setdefault("ajustes", {}).setdefault(k, AJ[k])
E = SPEC.get("escenas") or []; err = []
if len(E) < 3: err.append("hacen falta al menos 3 tomas (hay %d)" % len(E))
ks = [e.get("key") for e in E]
if len(set(ks)) != len(ks) or not all(ks): err.append("cada toma necesita una clave única (key)")
for e in E:
    t = (e.get("texto") or "").strip(); n = len(t.split()); k = e.get("key")
    if not t: err.append("«%s»: falta el texto de la frase" % k)
    if n > 26: err.append("«%s» tiene %d palabras: dividirla (máximo 26, una idea por frase)" % (k, n))
    if e.get("tipo", "tarjeta") not in TIPOS: err.append("«%s»: tipo «%s» desconocido (%s)" % (k, e.get("tipo"), ", ".join(TIPOS)))
if E:
    ult = (E[-1].get("texto") or "").strip()
    if not re.search(r"[.!?…»”\"]$", ult) or ult.rstrip(".!?…»”\"").split()[-1:] in (["y"], ["que"], ["porque"], ["pero"]): err.append("el cierre debe ser una frase completa que termine con puntuación")
t = 0.3; G = []
for e in E:
    G.append({"key": e["key"], "texto": e["texto"], "pausa": int(PAUSA * 1000), "t": round(t, 2)}); t += len(e["texto"]) * RITMO + PAUSA
dur = round(t, 1); seg = SPEC.get("seg")
if seg and not (.75 * seg <= dur <= 1.04 * seg): err.append("el tiempo estimado (%.0f s) debe estar entre el 75 %% y el 104 %% de los %s s pedidos" % (dur, seg))
# ---- AQUÍ van las reglas propias de tu plugin (p. ej. «≥ 3 citas», «primera frase empieza con…», palabras según duración) ----
if err: sal("la ficha no cumple las reglas del plugin:" + "".join("\n - " + x for x in err))
(SAL / "guion").mkdir(parents=True, exist_ok=True)
rd = lambda p: p.read_text(encoding="utf-8")
body = "const SPEC = %s;\n" % json.dumps({k: SPEC.get(k) for k in ("titulo", "subtitulos", "ajustes")} | {"escenas": E}, ensure_ascii=False)
(SAL / "game_head.js").write_text(rd(PLUG / "base" / "game_head.js"), encoding="utf-8"); (SAL / "game_body.js").write_text(body, encoding="utf-8"); (SAL / "game_tail.js").write_text(rd(PLUG / "base" / "game_tail.js"), encoding="utf-8")
(SAL / "game.js").write_text(rd(PLUG / "motor" / "motor.js") + "\n" + rd(SAL / "game_head.js") + "\n" + body + "\n" + rd(SAL / "game_tail.js") + "\n", encoding="utf-8")
(SAL / "index.html").write_text(rd(PLUG / "base" / "index.html").replace("__W__", str(W)).replace("__H__", str(H)), encoding="utf-8")
for n in ("1.json", "1_original.json"): (SAL / "guion" / n).write_text(json.dumps(G, ensure_ascii=False, indent=1), encoding="utf-8")
seo = dict(SPEC.get("seo") or {}); seo.setdefault("tipo", "tema"); seo.setdefault("sujeto", SPEC.get("titulo", ""))   # el bloque seo alimenta los títulos/descripción/etiquetas de la pestaña Publicar
(SAL / "proyecto.json").write_text(json.dumps({"id": PID, "idea": SPEC.get("idea", PID), "titulo": SPEC.get("titulo", PID), "formato": FORMATO, "aspecto": "16:9" if FORMATO == "largo" else "9:16", "plugin": "{{ID}}", "momentos": [e["texto"][:60] for e in E], "seo": seo}, ensure_ascii=False, indent=1), encoding="utf-8")
print("tiempo estimado: ~%.0f s%s · %d tomas · lienzo %dx%d" % (dur, (" de %s s pedidos" % seg) if seg else "", len(E), W, H))
print("ok %d frases -> %s" % (len(G), SAL))
