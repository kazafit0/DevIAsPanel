"""IDEAS del plugin «{{ID}}». El panel (pestaña Ideas) importa este módulo y llama a DOS funciones obligatorias:
    mas_ideas(formato, n, usados)  → lista de n ideas nuevas para ese formato («short» o «largo»), sin repetir las de `usados` (lista de títulos ya vistos)
    ideas_de(texto, formato)       → ideas para un pedido libre del usuario («haz un video sobre X»): suelen ser 6 formas distintas de contarlo
Cada idea es un diccionario: {"formato": "short"|"largo", "titulo": "...", "desc": "una o dos frases con el enfoque", "modo": "<tipo de idea, de plugin.json → ideas.tipos>"}
REGLA (error real de otro plugin): con pocas ideas, el 2.º lote salía vacío. Siempre debe poder pedirse otro lote: si ya se usaron casi todas, devuelve variantes con otro enfoque."""
import random, time
TEMAS = [  # (título del video, descripción / enfoque, modo)  ← SUSTITUYE por temas reales de tu plugin (y verifica sus datos)
    ("Un tema de ejemplo número uno", "Describe aquí de qué trata y con qué enfoque se contaría.", "tema"),
    ("Un tema de ejemplo número dos", "Otro enfoque distinto, con su propia gracia.", "tema"),
    ("Un tema de ejemplo número tres", "Y un tercero para que el panel tenga de dónde elegir.", "tema"),
    ("Un tema de ejemplo número cuatro", "Cuantos más temas reales traigas, mejor (mínimo 12 recomendados).", "tema"),
]
def mas_ideas(fm, n=10, usados=()):
    usados = set(usados); pool = [t for t in TEMAS if t[0] not in usados]; random.Random(int(time.time())).shuffle(pool)
    out = [{"formato": fm, "titulo": a + (" (versión completa)" if fm == "largo" else ""), "desc": b, "modo": c} for a, b, c in pool[:max(1, n)]]
    if len(out) < n:   # casi todo usado: variantes con otro enfoque, para que siempre haya otro lote
        for a, b, c in random.Random(7).sample(TEMAS, min(len(TEMAS), n - len(out))): out.append({"formato": fm, "titulo": a + " (otro enfoque)", "desc": "Mismo tema con otro enfoque. " + b, "modo": c})
    return out
def ideas_de(texto, fm):
    t = (texto or "").strip().rstrip(".?!"); t = t[:1].lower() + t[1:] if t else "tu tema"; r = random.Random(sum(map(ord, t)) + len(t))
    base = [("Lo que no sabías de %s" % t, "El dato que casi nadie conoce.", "tema"), ("%s en un minuto" % t.capitalize(), "Lo esencial, sin rodeos.", "tema"), ("La historia de %s" % t, "Cómo empezó todo.", "tema"),
            ("Mitos sobre %s" % t, "Qué es cierto y qué no.", "tema"), ("%s: lo que viene" % t.capitalize(), "Hacia dónde va.", "tema"), ("Por qué importa %s" % t, "La razón de fondo.", "tema")]
    r.shuffle(base); return [{"formato": fm, "titulo": a + (" (versión completa)" if fm == "largo" else ""), "desc": b, "modo": c} for a, b, c in base]
