# {{NOMBRE}} · diseño visual y sonoro

‹Todo lo que define el «aspecto» del plugin, con valores concretos (colores en hex, tamaños en px, posiciones en y). Cuanto más concreto, menos tendrá que adivinar Claude.›

- **Formatos:** short 9:16 (1080×1920) y largo 16:9 (1920×1080), 30 fps. ‹Cómo cambia la composición entre formatos.›
- **Paleta:** ‹colores base y para qué se usa cada uno.›
- **Tipografía:** ‹familias, pesos y tamaños; dónde va cada texto.›
- **Composición:** ‹zonas seguras, dónde va el sujeto, dónde el subtítulo (y < …), márgenes.›
- **Movimiento:** ‹cámara, entradas (pop/escala), duración de transiciones, qué NO se mueve.›
- **Elementos gráficos:** ‹cada elemento: cómo se ve y cuándo aparece.›
- **Sonido:** la voz (Voice Studio) va al frente y la mezcla la hace el panel. Los efectos se anuncian como `cues` del video (`cue('pop')`, `cue('whoosh')`…). ‹Qué cues emite este plugin y cuándo.›
- **Referencias visuales:** ‹enlaces o descripciones de lo que inspira el estilo (ver `referencia.md`).›
