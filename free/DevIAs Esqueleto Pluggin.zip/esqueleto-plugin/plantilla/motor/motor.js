/* {{NOMBRE}} · MOTOR VISUAL del plugin «{{ID}}».
   Aquí vive TODO lo que se dibuja. Regla de oro: cada función dibuja el fotograma de UN INSTANTE t (sin estado entre fotogramas), así sirve igual para la vista previa, para __adv(n) y para la grabación.
   Para añadir una clase de toma nueva: agrega una función a MOTOR.tipos con la firma (c, W, H, e, u, t) y úsala en la ficha con "tipo": "<nombre>".
     c = contexto 2D · W,H = tamaño del lienzo (1080×1920 short · 1920×1080 largo) · e = la toma de la ficha · u = avance de la toma 0..1 · t = segundos de la toma
   Sustituye este contenido de demostración por el estilo REAL de tu plugin (cielos, personajes, gráficos…). Todo en código: sin imágenes ni video de terceros salvo que la licencia lo permita. */
const MOTOR = (() => {
  const TAU = Math.PI * 2, clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v)), lerp = (a, b, t) => a + (b - a) * t, ease = t => 1 - Math.pow(1 - clamp(t), 3);
  const hash = n => { n = Math.sin(n * 127.1 + 311.7) * 43758.5453; return n - Math.floor(n); };   // ruido determinista: mismo n → mismo valor (nada de Math.random en el dibujo)
  const SANS = '"Poppins","Segoe UI",Arial,sans-serif';
  const AJ = { intensidad: 1, estilo_fondo: 'degradado' };   // se rellena desde la ficha (SPEC.ajustes)
  /* ---- tipos de toma (la demostración trae uno: «tarjeta») ---- */
  const tipos = {
    tarjeta(c, W, H, e, u, t) {
      const [c1, c2] = e.paleta || ['#1c1838', '#f0a050'], k = AJ.intensidad, g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, c1); g.addColorStop(1, c2); c.fillStyle = g; c.fillRect(0, 0, W, H);
      if (AJ.estilo_fondo === 'círculos') for (let i = 0; i < 14; i++) { c.fillStyle = 'rgba(255,255,255,' + (.05 + .06 * hash(i)) + ')'; c.beginPath(); c.arc(hash(i * 3.1) * W, (hash(i * 7.7) * H + t * 30 * k * (1 + hash(i))) % H, 40 + hash(i + 4) * 160, 0, TAU); c.fill(); }
      else if (AJ.estilo_fondo === 'líneas') { c.strokeStyle = 'rgba(255,255,255,.08)'; c.lineWidth = 3; for (let i = 0; i < 22; i++) { const y = ((i / 22) * H + t * 24 * k) % H; c.beginPath(); c.moveTo(0, y); c.lineTo(W, y + 40 * Math.sin(t + i)); c.stroke(); } }
      if (e.titulo) { const a = ease(t / .6); c.save(); c.globalAlpha = a; c.translate(0, (1 - a) * 40); c.font = '800 ' + Math.round(Math.min(W, H) * .075) + 'px ' + SANS; c.textAlign = 'center'; c.fillStyle = '#fff'; c.shadowColor = 'rgba(0,0,0,.45)'; c.shadowBlur = 18; c.fillText(e.titulo, W / 2, H * .42); c.restore(); }
    },
  };
  /* ---- subtítulo (una sola línea de la frase, hasta 3 líneas con ajuste automático) ---- */
  function subtitulo(c, W, H, texto, u) {
    const fs = Math.round(H * (W > H ? .042 : .026)), maxw = W * (W > H ? .78 : .88); c.save(); c.font = '600 ' + fs + 'px ' + SANS; c.textAlign = 'center'; c.globalAlpha = clamp(Math.min(u * 9, (1 - u) * 9));
    const ws = String(texto).split(/\s+/), L = []; let l = ''; ws.forEach(w => { const z = l ? l + ' ' + w : w; if (c.measureText(z).width > maxw && l) { L.push(l); l = w; } else l = z; }); if (l) L.push(l);
    const y0 = H * (W > H ? .9 : .84) - (L.length - 1) * fs * 1.25, bw = Math.max(...L.map(s => c.measureText(s).width)) + fs * 1.4;
    c.fillStyle = 'rgba(0,0,0,.5)'; c.beginPath(); c.roundRect ? c.roundRect(W / 2 - bw / 2, y0 - fs * 1.1, bw, L.length * fs * 1.25 + fs * .5, fs * .5) : c.rect(W / 2 - bw / 2, y0 - fs * 1.1, bw, L.length * fs * 1.25 + fs * .5); c.fill();
    c.fillStyle = '#fff'; L.slice(0, 3).forEach((s, i) => c.fillText(s, W / 2, y0 + i * fs * 1.25)); c.restore();
  }
  return { tipos, subtitulo, AJ, clamp, lerp, ease, hash, TAU, SANS };
})();
