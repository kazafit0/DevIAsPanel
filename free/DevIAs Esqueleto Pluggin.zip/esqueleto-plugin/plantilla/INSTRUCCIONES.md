# {{NOMBRE}} · instrucciones para Claude

> Este archivo es lo PRIMERO que lee Claude cuando el panel le pide un video de este plugin. Debe bastar para producir un video bueno sin preguntar. Rellena cada sección (borra los textos entre «‹ ›» al completarlos).

## Qué es (y qué no)
‹Describe en 5-8 líneas el estilo del plugin: qué se ve, qué se cuenta, para quién. Y qué NO es (para evitar malas interpretaciones).›

## Cómo se hace un video (en este orden)
1. **Lee** el pedido del panel (título, formato, duración, ajustes del plugin) y `memoria.md` (temas ya hechos y lo aprendido).
2. **Ideas:** el panel las pide a `ideas/ideas_{{MOD}}.py`. ‹Cómo se elige un tema bueno y cómo se verifican sus datos.›
3. **Guion** (texto limpio para la voz, sin acotaciones). ‹Estructura en bloques, duración por bloque, palabras totales según duración, tono.› Frases de ≤ 26 palabras, una idea por frase, el cierre es una frase completa.
4. **Ficha** (`specs/ID.json`, ver `specs/ejemplo.json`): `titulo`, `seg`, `formato`, `seo` (datos con fuente) y `escenas` (una por toma: `{key, texto, tipo, …}`).
5. **Construye:** `python plugins/{{ID}}/motor_{{MOD}}/construir.py plugins/{{ID}}/specs/ID.json ID [--formato short|largo]` (**con rutas absolutas y sin dejar tu terminal dentro de la carpeta del plugin**: en Windows eso impide que el panel mueva o desinstale el plugin y lo deja vacío). Crea `series/ID/`. Si la ficha no cumple las reglas, NO construye y dice qué corregir.
6. **Previsualiza** en el panel: `http://localhost:8820/series/ID/index.html?play=1` (reproduce) o `?t=SEGUNDOS` (un fotograma suelto). **Mira de verdad un fotograma de CADA toma en CADA formato** antes de decir «listo» (textos cortados, cosas bajo el subtítulo, tomas vacías).
7. **Borrador, voz y unión** los hace el panel con `pipeline/pipeline_{{MOD}}.py` (`borrador` → el usuario revisa → «Estoy conforme» → `voz`/`conforme`). **La voz solo se genera cuando el usuario dice «Estoy conforme».**
8. Avisa el avance con `python pedido.py IDEA_ID PORCENTAJE "mensaje" --etapa N` (etapas del cerebro: 1 Entender, 2 Guion, 3 Mapa/datos, 4 Personajes y escenas, 5 Gráficos, 6 Voz y tiempos, 7 Verificación, 8 Borrador listo).

## La ficha de cada toma
‹Documenta aquí CADA campo que acepta una toma (tipo, paleta, personajes, elementos…), con un ejemplo mínimo.›

| campo | obligatorio | qué hace |
|---|---|---|
| `key` | sí | identificador único de la toma (e01, e02…) |
| `texto` | sí | la frase que dice la voz (≤ 26 palabras) |
| `tipo` | no (`tarjeta`) | clase de toma que dibuja `motor/motor.js` |
| `titulo` | no | texto grande de la toma |
| `paleta` | no | dos colores `["#arriba", "#abajo"]` |

## Reglas de guion (las comprueba el constructor)
- ≥ 3 tomas, claves únicas, tipo conocido.
- Una idea por frase, máximo 26 palabras; el cierre es una frase completa (no termina en «y», «que», «porque»…).
- El tiempo estimado debe quedar entre el **75 % y el 104 %** de la duración pedida.
- ‹Reglas propias del plugin.›
- Los datos que se digan deben venir de una fuente (anótala en `seo.datos`); nada inventado.

## Ajustes del plugin (Plugins → Configurar)
‹Explica qué hace cada ajuste de `plugin.json → ajustes`. El constructor los lee de la variable de entorno `PLUGIN_AJUSTES` si la ficha no los trae.›

## Para agregar una clase de toma o un elemento nuevo
Función en `motor/motor.js` (`MOTOR.tipos.<nombre>(c, W, H, e, u, t)`, sin estado entre fotogramas), y su nombre en `TIPOS` de `motor_{{MOD}}/construir.py`. Documéntalo arriba y en `DISENO.md`.
