# {{NOMBRE}} · memoria

## Versiones
- 0.1.0 ({{FECHA}}): plugin creado desde el esqueleto.

## Temas / videos ya hechos (no repetir)
- (ninguno todavía: añade aquí cada video nuevo con su título y fecha)

## Aprendido (lo que costó descubrir)
- (anota aquí lo que el usuario corrigió, los errores que ya pasaron y cómo se arreglaron)
