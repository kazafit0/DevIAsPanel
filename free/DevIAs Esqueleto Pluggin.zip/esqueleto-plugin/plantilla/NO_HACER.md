# {{NOMBRE}} · lo que NO se hace

> Cada vez que el usuario critique algo de un video, la corrección se convierte en una línea aquí (con su porqué), no solo en un parche en ese video.

- **NO** traer voz, mezcla ni render propios: la voz (Voice Studio), la mezcla y el render son del DevIAs Panel. El verificador rechaza un plugin con `voz_*.py`, `mix*.py`, `grab*.py` o `unir.py`.
- **NO** generar la voz por tu cuenta: solo cuando el usuario dice «Estoy conforme».
- **NO** inventar datos: cada cifra, nombre o cita lleva su fuente en `seo.datos`.
- **NO** dejar tomas quietas, vacías ni con texto cortado o bajo el subtítulo.
- **NO** decir «listo» sin haber mirado un fotograma de cada toma en cada formato.
- **NO** dejar tu terminal con la carpeta del plugin como carpeta actual (Windows: impide mover/desinstalar el plugin y lo deja vacío). Usa rutas absolutas.
- **NO** meter en el plugin claves, tokens, rutas de tu equipo ni datos personales (el plugin se comparte como .zip).
- ‹Añade aquí las reglas propias del plugin.›
