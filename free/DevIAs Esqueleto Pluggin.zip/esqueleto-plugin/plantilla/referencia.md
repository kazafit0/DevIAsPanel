# {{NOMBRE}} · referencias

‹Enlaces, descripciones y capturas de las que sale el estilo del plugin, con su licencia. Regla: si reutilizas código o diseño de un tercero, deja aquí la atribución y la licencia (y respétala: p. ej. CC BY-NC = sin uso comercial).›

| Referencia | Qué se toma de ella | Licencia |
|---|---|---|
| ‹enlace› | ‹qué parte inspira o se reutiliza› | ‹licencia› |
