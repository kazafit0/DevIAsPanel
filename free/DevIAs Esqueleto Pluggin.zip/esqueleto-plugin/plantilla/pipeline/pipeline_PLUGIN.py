"""PIPELINE DEL PLUGIN «{{ID}}» — SOLO LA RECETA. El flujo (borrador → voz → unir), el render, la voz (Voice Studio), la mezcla, la música y el registro del video son del DevIAs Panel (motor/pipeline.py):
    borrador : tiempos ESTIMADOS desde el guion → se graba la escena muda → el usuario la revisa en el panel.
    voz      : la inicia el usuario con «Estoy conforme» → tiempos REALES → se regraba para que coincida.
    unir     : grabación final (30 fps) + música + mezcla + unión → video listo.
El plugin NO trae scripts de voz, mezcla ni render (el verificador del panel lo rechaza). Lo propio de un plugin:
  archivos      tuple   los archivos que dibujan el video (huella: si no cambian, el panel no regraba)
  preparar(P)           antes de todo: armar game.js desde sus piezas
  tras_tiempos(P)       (opcional) después de que haya tiempos nuevos, p. ej. recalcular algo que dependa de ellos
  escenas(P, fin)       lista [{n, titulo, desde, hasta}] para la mezcla por escenas (por defecto, una sola)
Variables de entorno que pone el panel al lanzar esto: DEVPANEL (carpeta del panel), PLUGIN_DIR (carpeta de este plugin), PLUGIN_AJUSTES (JSON con los ajustes). A mano, defínelas tú."""
import os, sys, pathlib
sys.path.insert(0, str(pathlib.Path(os.environ["DEVPANEL"]) / "motor")); import pipeline
def preparar(P):   # game.js = motor + cabeza + ficha + cola (sin esto el navegador no encuentra la película)
    plug = pathlib.Path(os.environ["PLUGIN_DIR"]); rd = lambda f: f.read_text(encoding="utf8")
    (P.R / "game.js").write_text(rd(plug / "motor" / "motor.js") + "\n" + "\n".join(rd(P.R / f) for f in ("game_head.js", "game_body.js", "game_tail.js") if (P.R / f).exists()) + "\n", encoding="utf8")
def escenas(P, fin): return [{"n": 1, "titulo": "Video completo", "desde": 0, "hasta": fin}]
pipeline.correr({"archivos": ("game.js",), "preparar": preparar, "escenas": escenas})
