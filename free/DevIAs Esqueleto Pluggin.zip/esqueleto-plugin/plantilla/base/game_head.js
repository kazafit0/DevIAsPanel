/* {{NOMBRE}} · CABEZA del juego. Define el lienzo, el reloj de la película (VT) y la carga de TIEMPOS. No suele hacer falta tocarla.
   Orden de armado del game.js de cada video: motor/motor.js + game_head.js + game_body.js (la ficha SPEC de ESE video) + game_tail.js */
const q = new URLSearchParams(location.search);
const cv = document.getElementById('cv'), ctx = cv.getContext('2d'), W = cv.width, H = cv.height;
let VT = 0, cues = [], LOG = [], SEED = +(q.get('seed') || 1), SCN = [], END = 10;
/* vista previa: si la ventana es más chica que el lienzo se escala para verlo entero (al grabar la ventana mide lo mismo que el lienzo y no escala) */
const ajusta = () => { const k = Math.min(1, innerWidth / W, innerHeight / H); cv.style.transform = k < 1 ? 'scale(' + k + ')' : ''; cv.style.left = k < 1 ? Math.max(0, (innerWidth - W * k) / 2) + 'px' : '0'; cv.style.top = k < 1 ? Math.max(0, (innerHeight - H * k) / 2) + 'px' : '0'; }; ajusta(); addEventListener('resize', ajusta);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const cue = (k, e = {}) => { cues.push(Object.assign({ v: +VT.toFixed(3), k }, e)); };   // cues = sucesos del video (pop, whoosh, ding…) que la mezcla del panel puede convertir en sonido
/* TIEMPOS («tiempos»: «guion» en plugin.json): audiolibro/tiempos.json lo calcula el panel (estimados en el borrador, REALES con la voz: tags {clave: [inicio, fin]}); sin él se usan los del guion (guion/1.json) */
async function cargaTiempos() {
  const T = {}; let dur = 0;
  try { const r = await fetch('audiolibro/tiempos.json', { cache: 'no-store' }); if (r.ok) { const t = await r.json(); Object.assign(T, t.tags || {}); dur = t.dur || 0; } } catch (e) { LOG.push('sin tiempos.json'); }
  if (!Object.keys(T).length) { try { const g = await (await fetch('guion/1.json', { cache: 'no-store' })).json(); g.forEach((f, i) => { T[f.key] = [f.t, i + 1 < g.length ? g[i + 1].t : f.t + 8]; }); dur = g.length ? g[g.length - 1].t + 9 : 30; } catch (e) { LOG.push('sin guion'); } }
  return { T, dur };
}
