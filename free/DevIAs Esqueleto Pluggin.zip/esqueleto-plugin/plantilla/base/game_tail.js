/* {{NOMBRE}} · COLA del juego: arma las tomas desde la ficha, dibuja cada fotograma y expone los GANCHOS que exige el grabador del panel:
     __ready (true al terminar de cargar) · __frame(dt) (avanza dt s y dibuja) · __adv(n) (salta n/30 s sin dibujar) · __sim(seed) (devuelve {V: duración}) · __done() · __cues · __log
   Probar sin grabar:  index.html?play=1 (reproduce)  ·  index.html?t=SEGUNDOS (un fotograma suelto) */
const M = MOTOR; Object.assign(M.AJ, SPEC.ajustes || {});
const sceneIdx = vt => { let i = 0; for (let k = 0; k < SCN.length; k++) if (vt >= SCN[k].t0) i = k; return i; };
async function build() {
  const { T, dur } = await cargaTiempos(), ks = SPEC.escenas; SCN = [];
  ks.forEach((e, i) => { const t = T[e.key] || [i * 8, i * 8 + 8], nxt = ks[i + 1] && T[ks[i + 1].key] ? T[ks[i + 1].key][0] : Math.max(dur, t[1]), t0 = i === 0 ? 0 : t[0]; SCN.push({ e, key: e.key, t0, dur: Math.max(.5, nxt - t0), visto: false }); });
  END = Math.max(dur, SCN.length ? SCN[SCN.length - 1].t0 + SCN[SCN.length - 1].dur : 10); cues.length = 0; LOG.push('tomas: ' + SCN.length);
}
function render() {
  if (!SCN.length) return; const i = sceneIdx(VT), sc = SCN[i], tl = VT - sc.t0, u = clamp(tl / sc.dur, 0, 1); if (!sc.visto) { sc.visto = true; cue(i ? 'whoosh' : 'inicio', { escena: sc.key }); }
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, W, H); ctx.save();
  const z = 1 + .04 * u * M.AJ.intensidad; ctx.translate(W / 2, H / 2); ctx.scale(z, z); ctx.translate(-W / 2, -H / 2);   // empuje de cámara lento dentro de cada toma
  (M.tipos[sc.e.tipo || 'tarjeta'] || M.tipos.tarjeta)(ctx, W, H, sc.e, u, tl); ctx.restore();
  if (SPEC.subtitulos !== false && sc.e.texto) M.subtitulo(ctx, W, H, sc.e.texto, u);
}
window.__sim = seed => { SEED = (seed | 0) || SEED; VT = END; return { seed: SEED, V: +END.toFixed(2), ganador: 0 }; };
window.__frame = dt => { VT += dt; render(); };
window.__done = () => VT >= END; window.__adv = n => { VT += n / 30; };
Object.defineProperty(window, '__cues', { get: () => cues }); Object.defineProperty(window, '__log', { get: () => LOG });
build().then(() => {
  window.__ready = true;
  if (q.get('t') != null) { VT = +q.get('t'); render(); }
  else if (q.get('play')) { let last = performance.now(); const loop = () => { const n = performance.now(); VT += Math.min(.05, (n - last) / 1000); last = n; if (VT > END + 1.5) { VT = 0; SCN.forEach(s => s.visto = false); } render(); requestAnimationFrame(loop); }; loop(); }
  else render();
}).catch(e => { LOG.push('ERROR: ' + (e && e.stack || e)); console.error(e); });
