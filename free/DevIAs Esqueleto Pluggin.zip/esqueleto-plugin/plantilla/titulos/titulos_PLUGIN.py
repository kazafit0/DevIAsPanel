"""TÍTULOS, DESCRIPCIÓN, HASHTAGS Y ETIQUETAS del plugin «{{ID}}» (pestaña Publicar). Se importa desde plugin.json → titulos.tipos (un módulo por tipo de video; pueden compartir el mismo).
Entrada: el bloque `seo` del proyecto.json →  f = {tipo, sujeto, hecho, pregunta, gancho, momentos:[...], datos:[...], hashtags:[...], tags_tema:[...]}
Función obligatoria:  generar(pid, f, lote, usados=(), largo=False)  →  lista de hasta 100 diccionarios:
    {"titulo", "descripcion", "etiquetas": [...], "score": 0-99, "motivo": [...], "largo": len(titulo), "hook_3s", "comentario_fijado", "hashtags": [...]}
Reglas: el gancho va primero, 30-75 caracteres, habla de LO QUE MUESTRA el video, 5 hashtags (#Shorts primero), etiquetas ≤ 500 caracteres en total.
REGLA (error real): siempre se puede pedir otro lote de 100: tantas combinaciones (núcleos × colas × emojis) que el 2.º y el 3.er lote no salgan vacíos ni repetidos (`usados` = títulos ya vistos)."""
import random, hashlib, re
EMO = ["✨", "🔥", "💡", "🎬", "👀", "📌", "🚀", "⭐"]
CORES = ["¿Sabías esto de {S}?", "{S}: lo que nadie te cuenta", "Mira esto de {S}", "{S} en un minuto", "Lo que no viste de {S}", "{S}: el dato que sorprende", "Así funciona {S}", "{S} explicado fácil", "La historia de {S}", "{S}: lo esencial",
         "Antes de que lo olvides: {S}", "{S}, paso a paso", "El secreto de {S}", "{S} como nunca lo viste", "Todo sobre {S}", "{S}: una curiosidad", "Lo mejor de {S}", "{S}: ¿mito o verdad?", "Por qué importa {S}", "{S}: la clave"]
COLAS = ["", "Con datos reales", "Te sorprenderá", "En menos de un minuto", "Mira hasta el final", "Para pensar", "Datos exactos", "Curiosidades", "Explicado", "Sin rodeos", "Lo esencial", "Paso a paso"]
TH = [((c + (" · " + t if t else "")).strip() + " {E}") for c in CORES for t in COLAS]   # 20 × 12 = 240 plantillas × 8 emojis
def _slug(s): return re.sub(r"[^A-Za-z0-9ÁÉÍÓÚÑáéíóúñ]", "", s.title())
def _tags(f):
    base = [(f.get("sujeto") or "").lower(), "curiosidades", "datos", "aprende", "shorts"] + list(f.get("tags_tema") or []); out, n, vistos = [], 0, set()
    for x in base:
        x = re.sub(r"\s+", " ", str(x).strip())
        if not x or x.lower() in vistos or len(x) > 60 or n + len(x) + 1 > 500: continue
        vistos.add(x.lower()); out.append(x); n += len(x) + 1
    return out
def _score(t, f): return min(99, 55 + (12 if 30 <= len(t) <= 75 else 0) + (8 if "¿" in t else 0) + (6 if (f.get("sujeto", "").lower() in t.lower()) else 0) + (6 if re.search(r"\d", t) else 0))
def generar(pid, f, lote, usados=(), largo=False):
    rnd = random.Random(int(hashlib.md5(("%s-%d-v1" % (pid, lote)).encode()).hexdigest()[:8], 16)); S = f.get("sujeto") or "este tema"; mom = f.get("momentos") or ["el inicio", "el dato", "el final"]; datos = f.get("datos") or []
    out, vistos, intentos, uso = [], set(usados), 0, {}
    while len(out) < 100 and intentos < 40000:
        intentos += 1; tpl = rnd.choice(TH); t = tpl.format(S=S, E=rnd.choice(EMO)).replace("  ", " ").strip(); t = re.sub(r"\s+([?!…])", r"\1", t); t = t[:1].upper() + t[1:]
        if t in vistos or len(t) > (75 if intentos < 12000 else 95) or uso.get(tpl, 0) >= 1 + intentos // 4000: continue
        uso[tpl] = uso.get(tpl, 0) + 1; vistos.add(t); m3 = rnd.sample(mom, min(3, len(mom))); dd = datos[:]; rnd.shuffle(dd)
        hs = ["#Shorts", "#" + _slug(S)[:28], "#Curiosidades", "#Aprende", "#Datos"]
        desc = "\n".join([f.get("hecho") or ("Un video sobre %s." % S), "En este video: " + ", ".join(m3) + "."] + ([" ".join("• %s" % z for z in dd[:3])] if dd else []) + ["", "💬 ¿Qué otro tema quieres ver? Te leo en los comentarios.", "", " ".join(hs)])
        out.append({"titulo": t, "descripcion": desc, "etiquetas": _tags(f), "score": _score(t, f), "motivo": ["curiosidad"], "largo": len(t), "hook_3s": rnd.choice(["¿Sabías esto?", "Mira esto", "Atento al final"]), "comentario_fijado": "¿Qué otro tema quieres ver?", "hashtags": hs})
    out.sort(key=lambda o: -o["score"]); return out[:100]
