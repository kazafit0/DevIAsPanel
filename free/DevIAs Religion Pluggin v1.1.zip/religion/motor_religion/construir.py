"""CONSTRUCTOR del plugin «religion» (DevIAs Panel). Convierte la FICHA (spec .json) de un reel bíblico en un PROYECTO listo para el panel:
    python construir.py SPEC.json ID_DEL_VIDEO [--carpeta RUTA_DE_SALIDA]
Crea series/ID/ con: index.html, game_head.js, game_body.js (la ficha), game_tail.js, game.js (todo junto), proyecto.json y guion/1.json (+_original).
Reglas que comprueba (si no se cumplen NO se construye):
  ≥ 3 tomas · claves únicas · cielo, personajes y elementos conocidos · una idea por frase (≤ 26 palabras) · el cierre es una frase COMPLETA · SIN llamada a la acción salvo spec.cta ·
  el tiempo estimado está entre el 75 % y el 104 % de la duración pedida (spec.seg) · la primera frase empieza «¿Sabías que» · palabras del guion según la duración (60-90 s: 120-185; 30 s: 48-78) ·
  ≥ 3 datos con su cita bíblica exacta en seo.datos (formato «Génesis 5:27») · palabras_clave · ≥ 2 elementos «cita» (píldora) repartidos en las tomas.
Ficha: {"titulo", "seg", "palabras_clave": [...], "cta": false, "seo": {...},
  "escenas": [{"key": "e01", "texto": "…frase…", "cielo": "atardecer|tormenta|noche|divino", "sol_x": .78,
               "personajes": [{"x": .45, "tipo": "anciano|joven|jesus", "escala": 1, "camina": false, "martillo": false, "vx": 0}],
               "arca": true | {"x": .83}, "lapida": {"texto": "NOMBRE", "x": .3}, "ciudad": false, "camino": false, "camara": {"z0": 1, "z1": 1.06, "pan": 0},
               "elementos": [{"tipo": "nombre|cita|contador|cadena|suma|linea_tiempo|cita_oro", "cuando": "palabra del guion en que aparece" | "t": seg, "visible": seg que se ve (omitido = hasta el final de la toma), …}]}]}"""
import sys, os, json, re, pathlib
HERE = pathlib.Path(__file__).resolve().parent; PLUG = HERE.parent; ROOT = PLUG.parent.parent
CIELOS = ("atardecer", "tormenta", "noche", "divino"); PERSONAS = ("anciano", "joven", "jesus"); ELEMS = ("nombre", "cita", "contador", "cadena", "suma", "linea_tiempo", "cita_oro")
RITMO = 0.0775; PAUSA = 0.25   # s por carácter (el mismo que usa el panel para estimar el borrador) y pausa entre frases
def sal(m): sys.exit("NO SE CONSTRUYE: " + m)
a = [x for x in sys.argv[1:] if not x.startswith("--")]
if len(a) < 2: sys.exit(__doc__)
SPEC = json.loads(pathlib.Path(a[0]).read_text(encoding="utf-8")); PID = a[1]
SAL = pathlib.Path(sys.argv[sys.argv.index("--carpeta") + 1]) if "--carpeta" in sys.argv else ROOT / "series" / PID
W, H = 1080, 1920
AJ = json.loads(os.environ.get("PLUGIN_AJUSTES") or "{}")   # ajustes del plugin (Plugins → Configurar): cta, subtitulos, caja_azul, grano
for k in ("cta", "subtitulos", "caja_azul", "grano"):
    if k not in SPEC and k in AJ: SPEC[k] = AJ[k]
E = SPEC.get("escenas") or []; err = []
if len(E) < 3: err.append("hacen falta al menos 3 tomas (hay %d)" % len(E))
ks = [e.get("key") for e in E]
if len(set(ks)) != len(ks) or not all(ks): err.append("cada toma necesita una clave única (key)")
fin_ok = re.compile(r"[.!?…»”\"]$")
for e in E:
    t = (e.get("texto") or "").strip(); n = len(t.split()); k = e.get("key")
    if not t: err.append("«%s»: falta el texto de la frase" % k)
    if n > 26: err.append("«%s» tiene %d palabras: dividirla (máximo 26, una idea por frase)" % (k, n))
    if e.get("cielo", "atardecer") not in CIELOS: err.append("«%s»: cielo «%s» desconocido (%s)" % (k, e.get("cielo"), ", ".join(CIELOS)))
    for p in e.get("personajes", []):
        if p.get("tipo", "anciano") not in PERSONAS: err.append("«%s»: personaje «%s» desconocido (%s)" % (k, p.get("tipo"), ", ".join(PERSONAS)))
    for el in e.get("elementos", []):
        if el.get("tipo") not in ELEMS: err.append("«%s»: elemento «%s» desconocido (%s)" % (k, el.get("tipo"), ", ".join(ELEMS)))
        if el.get("tipo") == "cita" and not re.search(r"\d+:\d+", el.get("texto", "")): err.append("«%s»: la cita «%s» debe llevar capítulo:versículo" % (k, el.get("texto")))
        if el.get("cuando") and not any(el["cuando"].lower() in w.lower() for w in t.split()): err.append("«%s»: el elemento «%s» espera la palabra «%s», que no está en la frase" % (k, el.get("tipo"), el["cuando"]))
if E and not fin_ok.search((E[-1].get("texto") or "").strip()): err.append("el cierre debe terminar con puntuación (frase completa)")
if E and (E[-1].get("texto") or "").strip().rstrip(".!?…»”\"").split()[-1:] in (["y"], ["que"], ["porque"], ["pero"]): err.append("el cierre debe ser una frase completa")
t = 0.3; G = []
for e in E:
    G.append({"key": e["key"], "texto": e["texto"], "pausa": int(PAUSA * 1000), "t": round(t, 2)}); t += len(e["texto"]) * RITMO + PAUSA
dur = round(t, 1); seg = SPEC.get("seg")
if seg and not (.75 * seg <= dur <= 1.04 * seg): err.append("el tiempo estimado (%.0f s) debe estar entre el 75 %% y el 104 %% de los %s s pedidos" % (dur, seg))
pal_ = sum(len((e.get("texto") or "").split()) for e in E)
if not (E and re.match(r"¿\s*Sabías que", (E[0].get("texto") or "").strip(), re.I)): err.append("la primera frase (gancho) debe empezar con «¿Sabías que…»")
lo_, hi_ = (120, 185) if not seg or seg >= 60 else (int(seg * 1.6), int(seg * 2.6))   # el rango de palabras escala con la duración pedida
if not (lo_ <= pal_ <= hi_): err.append("el guion tiene %d palabras: debe tener entre %d y %d" % (pal_, lo_, hi_))
cit = [d_ for d_ in (SPEC.get("seo") or {}).get("datos", []) if re.search(r"\d?\s?[A-Za-zÁÉÍÓÚÑáéíóúñ]+\s\d+:\d+", d_)]
if len(cit) < 3: err.append("hacen falta al menos 3 datos con su cita bíblica exacta en seo.datos (formato «Génesis 5:27»): hay %d" % len(cit))
if not SPEC.get("palabras_clave"): err.append("falta palabras_clave (nombres, números y palabras que se resaltan en el subtítulo)")
if sum(1 for e in E for el in e.get("elementos", []) if el.get("tipo") == "cita") < 2: err.append("hacen falta al menos 2 elementos «cita» (píldora con libro y versículo) repartidos en las tomas")
cta_txt = re.compile(r"\b(sígueme|sigueme|suscr[ií]be|dale like|comparte|comenta)\b", re.I)
if not SPEC.get("cta") and any(cta_txt.search(e.get("texto") or "") for e in E): err.append("el guion pide seguir/compartir/suscribirse: por defecto el cierre va SIN llamada a la acción (activa spec.cta solo si el usuario lo pide)")
if err: sal("la ficha no cumple las reglas del plugin:" + "".join("\n - " + x for x in err))
(SAL / "guion").mkdir(parents=True, exist_ok=True)
rd = lambda p: p.read_text(encoding="utf-8")
body = "const SPEC = %s;\n" % json.dumps({k: SPEC.get(k) for k in ("titulo", "palabras_clave", "subtitulos", "caja_azul", "grano", "cta")} | {"escenas": E}, ensure_ascii=False)
(SAL / "game_head.js").write_text(rd(PLUG / "base" / "game_head.js"), encoding="utf-8"); (SAL / "game_body.js").write_text(body, encoding="utf-8"); (SAL / "game_tail.js").write_text(rd(PLUG / "base" / "game_tail.js"), encoding="utf-8")
(SAL / "game.js").write_text(rd(PLUG / "motor" / "religion.js") + "\n" + rd(SAL / "game_head.js") + "\n" + body + "\n" + rd(SAL / "game_tail.js") + "\n", encoding="utf-8")
(SAL / "index.html").write_text(rd(PLUG / "base" / "index.html").replace("__W__", str(W)).replace("__H__", str(H)), encoding="utf-8")
for n in ("1.json", "1_original.json"): (SAL / "guion" / n).write_text(json.dumps(G, ensure_ascii=False, indent=1), encoding="utf-8")
seo = dict(SPEC.get("seo") or {}); seo.setdefault("tipo", "biblico"); seo.setdefault("sujeto", SPEC.get("titulo", ""))
(SAL / "proyecto.json").write_text(json.dumps({"id": PID, "idea": SPEC.get("idea", PID), "titulo": SPEC.get("titulo", PID), "formato": "short", "aspecto": "9:16", "plugin": "religion", "momentos": [e["texto"][:60] for e in E], "seo": seo}, ensure_ascii=False, indent=1), encoding="utf-8")
print("tiempo estimado: ~%.0f s%s · %d tomas · %d palabras · lienzo %dx%d" % (dur, (" de %s s pedidos" % seg) if seg else "", len(E), pal_, W, H))
print("ok %d frases -> %s" % (len(G), SAL))
