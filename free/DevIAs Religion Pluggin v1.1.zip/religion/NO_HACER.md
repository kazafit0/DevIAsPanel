# Religión · lo que NO se hace

- **NO inventar datos bíblicos.** Cada cifra y cada versículo se comprueba. Si algo se discute: «hay quien traduce…» / «muchos creen…». Nada de prédica ni de afirmar lo que la Biblia no dice.
- **NO poner llamada a la acción** («sígueme», «comparte», «suscríbete») salvo que el usuario la pida (ajuste «Tarjeta de seguir»). El cierre es la frase espiritual.
- **NO generar la voz por tu cuenta:** la voz (Voice Studio) la inicia el usuario con «Estoy conforme». **No lleva voz propia ni descarga de voces.**
- **NO usar imágenes, fotos ni video/IA de terceros:** todo se dibuja en código.
- **NO dejar tomas quietas ni vacías;** nada importante bajo el subtítulo (y < 420) ni cortado en los bordes.
- **NO dibujar caras detalladas** a los personajes: siluetas con barba blanca y borde dorado.
- **NO repetir un tema ya hecho** (`memoria.md`).
- **NO dejar tu terminal dentro de la carpeta del plugin** (en Windows impide mover/desinstalar el plugin y lo deja vacío): usa rutas absolutas.
- **NO escribir «reportaje» ni etiquetas internas en pantalla.**
