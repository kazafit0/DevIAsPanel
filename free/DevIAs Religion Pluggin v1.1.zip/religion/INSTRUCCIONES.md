# Religión · reels bíblicos «¿Sabías que…?» · instrucciones para Claude

Plugin del DevIAs Panel para **reels verticales 9:16 de 30 a 90 s** con un **dato bíblico exacto y verificable** (edades, medidas, genealogías, cifras que coinciden), contado con **ilustración vectorial plana animada en código** (canvas 2D, sin imágenes ni video de terceros). Estilo de referencia: reel «Matusalén y el diluvio» (ver `referencia_religion.md`). **La voz la pone Voice Studio desde el panel**: este plugin no tiene voz propia.

## Cómo se hace un video (en este orden)
1. **Lee** el pedido del panel y los ajustes del plugin (tarjeta de seguir, subtítulos, caja azul, grano, cantidad de tomas).
2. **Ideas:** el panel pide ideas a `ideas/ideas_religion.py`. Cada tema trae título-gancho (≤ 14 palabras), el dato o giro, las **citas comprobadas** y la imagen ancla. Evita los temas ya hechos (`memoria.md`).
3. **Guion** (texto limpio para la voz, sin acotaciones). Duración **60–75 s ≈ 150–185 palabras**; en pedidos más cortos escala (30 s ≈ 50–75 palabras). Frases cortas (≤ 26 palabras, una imagen por frase), tono solemne-informativo, segunda persona puntual («para que te hagas una idea», «ahora suma»). Los 9 bloques:

| # | Bloque | Seg. | Ejemplo Matusalén |
|---|---|---|---|
| 1 | Gancho «¿Sabías que…?» con contradicción | 0–4 | «…murió justo el año del diluvio?» |
| 2 | Nombre + número grande | 5–9 | «Se llamaba Matusalén y vivió 969 años.» |
| 3 | Comparación moderna | 10–14 | «si hubiera nacido en la Edad Media, hoy seguiría vivo» |
| 4 | Contexto / personaje relacionado | 15–20 | Enoc, que caminaba con Dios |
| 5 | Cadena de datos (3 números con cita) | 21–31 | 187 → 182 → 600 |
| 6 | «Ahora suma» — la revelación | 32–44 | 187+182+600 = 969, «exactamente» |
| 7 | Capa extra de misterio (nombre, traducción, profecía) | 45–48 | «cuando él muera, será enviado» |
| 8 | Lectura espiritual con versículo | 49–62 | 1 Pedro 3:20, la paciencia de Dios |
| 9 | Cierre | 62–66 | **sin llamada a la acción** (por defecto); termina con la frase espiritual |

   **Reglas de contenido:** solo datos bíblicos exactos (revisa cifras y versículos); si una tradición o traducción es discutida di «hay quien traduce…» / «muchos creen…». Cada frase debe poder dibujarse. Los números se escriben con letras en el guion (para la voz) y con cifras en pantalla.
4. **Ficha** (`specs/ID.json`, ver `specs/ejemplo_matusalen.json`): `titulo`, `seg`, `palabras_clave`, `seo` (con ≥ 3 `datos` con cita), `escenas` (una por toma).
5. **Construye:** `python plugins/religion/motor_religion/construir.py plugins/religion/specs/ID.json ID` (ruta absoluta; **nunca dejes tu terminal con la carpeta del plugin como carpeta actual**: en Windows impide que el panel mueva el plugin y lo deja vacío). Crea `series/ID/`. **Si la ficha no cumple las reglas, NO construye** y dice qué corregir.
6. **Previsualiza:** `http://localhost:8820/series/ID/index.html?play=1` o `?t=SEGUNDOS`. Mira un fotograma de **cada toma** (≈ 60 % de su duración): textos cortados, elementos bajo el subtítulo (y < 420), tomas vacías.
7. **Borrador, voz y unión** los hace el panel con `pipeline/pipeline_religion.py`. **La voz solo se genera cuando el usuario dice «Estoy conforme».**

## La ficha de cada toma
`{key, texto, cielo, sol_x?, personajes[], arca?, lapida?, ciudad?, camino?, camara?, elementos[]}`
- `cielo`: **atardecer** (morado-naranja, escena base), **tormenta** (lluvia diagonal + rayo con flash; el gancho/diluvio), **noche** (estrellas y luna; comparación moderna, misterio), **divino** (rayos de luz; cierre).
- `personajes`: `{x (0–1), tipo: anciano|joven|jesus, escala, lado?, camina?, martillo?, vx?, brillo?}`. Casi negros, de perfil, borde dorado del lado del sol. El anciano: manto con capucha hasta el suelo, barba blanca, bastón de pastor dorado más alto que él. Los secundarios: túnica corta y más delgados.
- Objetos ancla: `arca` (caja larga oscura con ventana amarilla encendida, siempre en el horizonte a la derecha; aparece en el gancho y vuelve al final), `lapida {texto}` (se ilumina en dorado), `ciudad` (ventanas encendidas), `camino` (línea dorada con chispa entre dos personajes).
- `elementos` (aparecen en la **palabra** que se dice: `"cuando": "palabra"`, o en un segundo `"t"`; `"visible"` = cuántos segundos se ven):
  - `nombre {texto, sub?}` serif dorado mayúsculas que se escribe letra a letra (y≈330).
  - `cita {texto}` píldora con borde dorado («Génesis 5:24», y≈1650). El bastón brilla cuando se nombra.
  - `contador {valor, desde?, color: amarillo|naranja|azul|verde|rojo, etiqueta?, x?, y?, dur?}` cuenta hacia arriba (179→187, 598→600).
  - `cadena {items[]}` chips «A → B → C» que se encienden uno a uno (y≈340).
  - `suma {partes[], total, comparar?: [«nace X», «muere · Y»], etiqueta?}` barra segmentada que se llena + total en cápsula + barra crema comparativa con extremos punteados.
  - `linea_tiempo {desde, hasta, etiqueta}` línea dorada con extremos y cápsula («1057 — 2026», «969 años»).
  - `cita_oro {lineas[]}` cita larga en dorado con brillo.
- `camara {z0, z1, pan}`: empuje lento por defecto (1 → 1,06); zoom out progresivo en la cadena genealógica; paneo en comparaciones.

## Reglas de ritmo y composición
- **Cambio de toma cada 4–8 s**, con algo nuevo apareciendo cada 1,5–3 s; ninguna toma quieta (respiración, nubes, lluvia, chispa, cámara).
- Personaje en el tercio medio-inferior (x≈430–550 de 1080); el tercio superior es del subtítulo y del nombre.
- **Subtítulo** arriba (top≈190, máx. 3 palabras a la vez): las palabras ya dichas en gris al 55 %, la actual en blanco y negrita; **palabras clave** (nombres, cifras, «diluvio», «Dios», «exactamente») dentro de una **caja azul de selección** con dos tiradores, una cada 2–3 s.
- **Cierre circular** con la escena del gancho y luz divina. **Sin CTA** salvo que el usuario lo pida (ajuste «Tarjeta de seguir al final»).

## Para agregar un elemento o personaje nuevo
Función en `motor/religion.js` (dibuja el fotograma de un instante, sin estado) y su nombre en `ELEMS`/`PERSONAS` de `motor_religion/construir.py`. Todo en canvas 2D; nada de imágenes ni video de IA.
