"""PIPELINE DEL PLUGIN «religion» — SOLO LA RECETA. El flujo (borrador -> voz -> unir), el render, la voz (Voice Studio), la mezcla y el registro son del DevIAs Panel (motor/pipeline.py).
Lo propio de este plugin: armar game.js desde sus piezas (motor visual + cabeza + ficha del video + cola) y declarar la escena completa para la mezcla."""
import os, sys, pathlib
sys.path.insert(0, str(pathlib.Path(os.environ["DEVPANEL"]) / "motor")); import pipeline
def preparar(P):   # game.js = motor + cabeza + ficha + cola (sin esto el navegador no encuentra la película)
    plug = pathlib.Path(os.environ["PLUGIN_DIR"]); rd = lambda f: f.read_text(encoding="utf8")
    (P.R / "game.js").write_text(rd(plug / "motor" / "religion.js") + "\n" + "\n".join(rd(P.R / f) for f in ("game_head.js", "game_body.js", "game_tail.js") if (P.R / f).exists()) + "\n", encoding="utf8")
def escenas(P, fin): return [{"n": 1, "titulo": "Reel completo", "desde": 0, "hasta": fin}]
pipeline.correr({"archivos": ("game.js",), "preparar": preparar, "escenas": escenas})
