# Religión · memoria (temas ya hechos y lo aprendido)

## Temas ya hechos (no repetir)
- (ninguno todavía: añade aquí cada video nuevo con su título y fecha)

## Ejemplo de la casa
- `specs/ejemplo_matusalen.json`: «¿Sabías que el hombre que más vivió en la Biblia murió el año del diluvio?» (11 tomas, 75 s, 167 palabras; 187 + 182 + 600 = 969).

## Aprendido
- La suma de Matusalén sale de Génesis 5:25 (187 al nacer Lamec), 5:28-29 (182 al nacer Noé) y 7:6 (600 al diluvio) = 969 (Génesis 5:27). Que murió «el año del diluvio» es un cálculo con esas cifras: se dice «según las cifras del Génesis».
- El nombre «Matusalén» se explica a veces como «cuando él muera, será enviado»: es una etimología discutida → «hay quien traduce…».
- Los elementos aparecen en su palabra del guion (`cuando`): así los números llegan justo cuando la voz los dice, y no hay que ajustar segundos a mano.

## Versiones
- 1.1.0 (2026-11-23): Primera versión publicada en free: reels bíblicos estilo Matusalén (cielos, siluetas, cita, contador, cadena, suma, subtítulo con caja azul)
