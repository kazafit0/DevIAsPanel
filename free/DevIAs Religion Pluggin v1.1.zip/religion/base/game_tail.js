/* RELIGIÓN · cola del juego: arma las tomas desde la ficha, calcula cuándo se dice cada palabra (subtítulo y elementos que aparecen en su palabra), dibuja cada fotograma y expone los
   ganchos que pide el grabador del panel (__ready, __sim, __frame, __adv, __done, __cues, __log). Previsualizar: index.html?play=1  ·  un fotograma suelto: index.html?t=SEGUNDOS */
const R = REL, norm = s => String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]/g, '');
const layer = document.createElement('canvas'); layer.width = W; layer.height = H; const lctx = layer.getContext('2d');
const RITMO = .0775;   // s por carácter: el mismo ritmo con que el panel estima el borrador
const sceneIdx = vt => { let i = 0; for (let k = 0; k < SCN.length; k++) if (vt >= SCN[k].t0) i = k; return i; };
async function build() {
  try { await Promise.race([Promise.all(['700 40px Cinzel', '600 40px Poppins', '800 40px Poppins', '600 italic 40px "Cormorant Garamond"'].map(f => document.fonts.load(f))), new Promise(r => setTimeout(r, 3500))]); } catch (e) {}
  const { T, dur } = await cargaTiempos(), ks = SPEC.escenas, claves = (SPEC.palabras_clave || []).flatMap(p => String(p).split(/\s+/)).map(norm).filter(x => x.length > 1); SCN = []; PAL = [];
  ks.forEach((e, i) => {
    const t = T[e.key] || [i * 8, i * 8 + 8], nxt = ks[i + 1] && T[ks[i + 1].key] ? T[ks[i + 1].key][0] : Math.max(dur, t[1]), t0 = i === 0 ? 0 : t[0], d = Math.max(.5, nxt - t0);
    const ws = String(e.texto).split(/\s+/).filter(Boolean), car = ws.reduce((a, w) => a + w.length + 1, 0), habla = clamp(car * RITMO, .5, d - .2); let cum = 0;
    const palabras = ws.map(w => { const a = t0 + .12 + cum / car * habla; cum += w.length + 1; return { w, t0: a, t1: t0 + .12 + cum / car * habla, clave: claves.includes(norm(w)) }; });
    palabras.forEach(p => PAL.push(p));
    const els = (e.elementos || []).map((el, j) => { let tt = typeof el.t === 'number' ? el.t : null; if (tt == null && el.cuando) { const k = norm(el.cuando), p = palabras.find(p => norm(p.w).includes(k)); if (p) tt = Math.max(0, p.t0 - t0 - .05); } if (tt == null) tt = .8 + j * 1.2; return Object.assign({}, el, { tt, hecho: false }); });
    SCN.push({ key: e.key, e, t0, dur: d, els, palabras });
  });
  let ult = -9; PAL.forEach(p => { if (p.clave) { if (p.t0 - ult < 2.2) p.clave = false; else ult = p.t0; } });   // una palabra clave cada 2-3 s
  GRUPOS = []; let g = null; PAL.forEach(p => { if (!g || g.p.length >= 3 || g.p.reduce((a, x) => a + x.w.length, 0) + p.w.length > 20) { g = { p: [], t0: p.t0, t1: 0 }; GRUPOS.push(g); } g.p.push(p); });
  GRUPOS.forEach((x, i) => { x.t1 = i + 1 < GRUPOS.length ? Math.min(GRUPOS[i + 1].t0, x.p[x.p.length - 1].t1 + .5) : x.p[x.p.length - 1].t1 + .4; });
  END = Math.max(dur, SCN.length ? SCN[SCN.length - 1].t0 + SCN[SCN.length - 1].dur : 10); cues.length = 0; LOG.push('tomas: ' + SCN.length + ' · palabras: ' + PAL.length);
}
function pintaToma(c, sc, tl, tg) {   // una toma completa en el instante local tl (todo dentro de la cámara con empuje lento)
  const e = sc.e, u = clamp(tl / sc.dur, 0, 1), cam = e.camara || {}, z = R.lerp(cam.z0 || 1, cam.z1 || 1.06, R.eIO(u));
  c.save(); c.translate(W / 2 + (cam.pan || 0) * (u - .5), H * .62); c.scale(z, z); c.translate(-W / 2, -H * .62);
  const info = R.cielo(c, W, H, e.cielo || 'atardecer', tg, { sol_x: e.sol_x }), hz = info.hz, yb = hz + (H - hz) * .3;
  if (e.ciudad) R.ciudad(c, W * .5, hz + 6, W * 1.1, tg);
  if (e.arca) { const a = e.arca === true ? {} : e.arca; R.arca(c, W * (a.x != null ? a.x : .83), hz + 10, a.escala || .52, tg, a); }
  if (e.lapida) R.lapida(c, W * (e.lapida.x != null ? e.lapida.x : .3), yb + 20, e.lapida.escala || 1, tg, { texto: e.lapida.texto, luz: e.lapida.luz == null ? R.seg(tl, 1, 1.8) : e.lapida.luz });
  const ps = e.personajes || [{ x: .45, tipo: 'anciano' }], brillo = sc.els.some(el => el.tipo === 'cita' && tl >= el.tt && tl < el.tt + 1.1) ? 1 : 0;
  if (e.camino && ps.length > 1) R.camino(c, W * ps[0].x, W * ps[1].x, yb + 30, tg);
  ps.forEach((p, j) => { const vx = p.vx || 0; R.persona(c, W * p.x + vx * tl, yb, p.escala || 1, tg, { tipo: p.tipo, lado: p.lado || info.lado, camina: p.camina, martillo: p.martillo, brillo: p.brillo != null ? p.brillo : brillo, fase: j * 1.7 }); });
  sc.els.forEach(el => { const ul = tl - el.tt; if (ul < 0 || (el.visible && ul > el.visible)) return; const f = R[el.tipo === 'linea_tiempo' ? 'lineaTiempo' : el.tipo === 'cita_oro' ? 'citaOro' : el.tipo]; if (f && el.tipo !== 'cta') f(c, W, ul, el); if (!el.hecho && c === ctx) { el.hecho = true; cue(el.tipo === 'cita' ? 'sparkle' : el.tipo === 'suma' ? 'ding' : 'pop', { elemento: el.tipo }); } });
  c.restore();
}
function render() {
  if (!SCN.length) return; lastVT = VT;
  const i = sceneIdx(VT), sc = SCN[i], tl = VT - sc.t0; if (!sc.visto) { sc.visto = true; if (i) cue('whoosh', { escena: sc.key }); }
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  if (i > 0 && tl < .35) { const pv = SCN[i - 1]; pintaToma(ctx, pv, pv.dur, VT); lctx.setTransform(1, 0, 0, 1, 0, 0); lctx.clearRect(0, 0, W, H); pintaToma(lctx, sc, tl, VT); ctx.globalAlpha = R.eOut(tl / .35); ctx.drawImage(layer, 0, 0); ctx.globalAlpha = 1; }
  else pintaToma(ctx, sc, tl, VT);
  if (SPEC.subtitulos !== false) R.subtitulos(ctx, W, VT, GRUPOS, SPEC.caja_azul !== false);
  const cta = SPEC.cta && VT > END - 4.2; if (cta) R.tarjetaCTA(ctx, W, H, VT - (END - 4.2), {});
  R.grano(ctx, W, H, VT, SPEC.grano == null ? 1 : SPEC.grano);
}
window.__sim = seed => { SEED = (seed | 0) || SEED; VT = END; return { seed: SEED, V: +END.toFixed(2), ganador: 0 }; };
window.__frame = dt => { VT += dt; render(); };
window.__done = () => VT >= END; window.__adv = n => { VT += n / 30; };
Object.defineProperty(window, '__cues', { get: () => cues }); Object.defineProperty(window, '__log', { get: () => LOG });
build().then(() => {
  window.__ready = true;
  if (q.get('t') != null) { VT = +q.get('t'); render(); }
  else if (q.get('play')) { let last = performance.now(); const loop = () => { const n = performance.now(); VT += Math.min(.05, (n - last) / 1000); last = n; if (VT > END + 1.5) { VT = 0; SCN.forEach(s => { s.visto = false; s.els.forEach(el => el.hecho = false); }); } render(); requestAnimationFrame(loop); }; loop(); }
  else render();
}).catch(e => { LOG.push('ERROR: ' + (e && e.stack || e)); console.error(e); });
