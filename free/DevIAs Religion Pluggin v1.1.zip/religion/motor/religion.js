/* RELIGIÓN · motor visual del plugin «religion» (DevIAs Panel). Todo se DIBUJA EN CÓDIGO sobre canvas 2D (sin imágenes ni video de terceros): ilustración vectorial plana con degradados suaves y grano finísimo.
   Cada función es PURA respecto al tiempo: dibuja el fotograma de un instante t (así sirve para vista previa, __adv y grabación). Lienzo base 1080×1920; horizonte en y≈1410. Estilo «Matusalén»:
   atardecer morado-naranja, siluetas casi negras (#2b2118) con borde de luz dorado (#e8b25a), arca con ventana encendida, píldoras de cita, contadores, barra de suma, nombres en serif dorado. */
const REL = (() => {
  const TAU = Math.PI * 2, SANS = '"Poppins","Montserrat","Segoe UI",Arial,sans-serif', SERIF = '"Cinzel","Cormorant Garamond","Trajan Pro",Georgia,serif';
  const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v)), lerp = (a, b, t) => a + (b - a) * t, seg = (t, a, b) => clamp((t - a) / (b - a));
  const eOut = t => 1 - Math.pow(1 - clamp(t), 3), eIO = t => { t = clamp(t); return t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; }, eBack = (t, s = 1.7) => { t = clamp(t) - 1; return 1 + t * t * ((s + 1) * t + s); };
  const hash = n => { n = Math.sin(n * 127.1 + 311.7) * 43758.5453; return n - Math.floor(n); };
  const ORO = '#e8b25a', ORO2 = '#f0c060', OSC = '#2b2118', HZ = .735;
  const rr = (c, x, y, w, h, r) => { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); };
  const grad = (c, x0, y0, x1, y1, st) => { const g = c.createLinearGradient(x0, y0, x1, y1); st.forEach(([o, col]) => g.addColorStop(o, col)); return g; };
  const glow = (c, x, y, r, col, a) => { const g = c.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, col.replace('A', a)); g.addColorStop(1, col.replace('A', 0)); c.fillStyle = g; c.fillRect(x - r, y - r, 2 * r, 2 * r); };
  const texto = (c, s, x, y, font, fill, al = 'center', ls = 0) => { c.font = font; c.textAlign = al; c.textBaseline = 'alphabetic'; c.fillStyle = fill; if (!ls) { c.fillText(s, x, y); return; }
    let w = 0; for (const ch of s) w += c.measureText(ch).width + ls; w -= ls; let px = al === 'center' ? x - w / 2 : al === 'right' ? x - w : x; c.textAlign = 'left'; for (const ch of s) { c.fillText(ch, px, y); px += c.measureText(ch).width + ls; } };

  /* ---------------- CIELOS ---------------- */
  const CIELOS = {
    atardecer: { st: [[0, '#1c1838'], [.3, '#4a2f6a'], [.52, '#6a3f70'], [.7, '#c0605a'], [.86, '#f0a050'], [1, '#f8c878']], sol: '#ffe7b0', nube: '255,214,170', colina: ['#5a3f6e', '#44325a'], suelo: ['#2a2016', '#1a140e'] },
    tormenta: { st: [[0, '#0e0d1c'], [.35, '#262338'], [.6, '#3e3548'], [.82, '#7a4a46'], [1, '#b87a4a']], sol: '#d8c8b0', nube: '150,150,170', colina: ['#3a2f4a', '#2a2238'], suelo: ['#1c1610', '#100c08'] },
    noche: { st: [[0, '#0a0f2a'], [.5, '#151c4a'], [1, '#26306a']], sol: '#f4f4ff', nube: '120,130,190', colina: ['#1c2150', '#10153a'], suelo: ['#14121c', '#0a0810'] },
    divino: { st: [[0, '#22244a'], [.3, '#5a5a98'], [.6, '#b8a4b8'], [.85, '#f0d89a'], [1, '#fff4d0']], sol: '#fffbe8', nube: '255,244,214', colina: ['#6a5a86', '#4a3e68'], suelo: ['#2a2218', '#1a140e'] },
  };
  function cielo(c, W, H, tipo, t, o = {}) {
    const K = CIELOS[tipo] || CIELOS.atardecer, hz = H * HZ, sx = W * (o.sol_x != null ? o.sol_x : .78), sy = tipo === 'noche' ? H * .2 : hz - 170, lado = sx > W / 2 ? 1 : -1;
    c.fillStyle = grad(c, 0, 0, 0, hz, K.st); c.fillRect(0, 0, W, hz + 4);
    if (tipo === 'noche') for (let i = 0; i < 70; i++) { const tw = .5 + .5 * Math.sin(t * 2 + i * 5.1); c.fillStyle = 'rgba(255,255,255,' + (.35 + .5 * tw * hash(i)) + ')'; c.beginPath(); c.arc(hash(i * 3.3) * W, hash(i * 7.7) * hz * .7, 1 + hash(i + 9) * 2, 0, TAU); c.fill(); }
    glow(c, sx, sy, 520, tipo === 'noche' ? 'rgba(200,210,255,A)' : 'rgba(255,214,150,A)', tipo === 'tormenta' ? .22 : .5);
    c.fillStyle = K.sol; c.beginPath(); c.arc(sx, sy, tipo === 'noche' ? 86 : 132, 0, TAU); c.fill();
    if (tipo !== 'noche') { c.fillStyle = 'rgba(190,100,80,.28)'; for (let i = 0; i < 6; i++) c.fillRect(sx - 140, sy + 28 + i * 20, 280, 5 + i); }   // rayas horizontales del sol
    for (let i = 0; i < 10; i++) { const w = 220 + hash(i) * 340, x = ((hash(i * 2.1) * (W + 500) + t * (6 + hash(i + 4) * 10)) % (W + 500)) - 250, y = hz * (.18 + .62 * hash(i * 5.3)); c.fillStyle = 'rgba(' + K.nube + ',' + (tipo === 'tormenta' ? .32 : .26 + hash(i) * .16) + ')'; rr(c, x, y, w, 12 + hash(i + 8) * 14, 8); c.fill(); }   // nubes en franjas finas
    if (tipo === 'divino') for (let i = 0; i < 7; i++) { const a = 2.05 + i * .13, al = .08 + .05 * Math.sin(t * .8 + i); c.fillStyle = 'rgba(255,240,190,' + al + ')'; c.beginPath(); c.moveTo(W * .95, -40); c.lineTo(W * .95 + Math.cos(a) * 2600 - 60, Math.sin(a) * 2600); c.lineTo(W * .95 + Math.cos(a) * 2600 + 60, Math.sin(a) * 2600); c.closePath(); c.fill(); }
    // colinas y suelo
    [[0, 150, K.colina[0], 1.3], [1, 90, K.colina[1], 2.1]].forEach(([k, amp, col, f]) => { c.fillStyle = col; c.beginPath(); c.moveTo(0, hz + 10); for (let x = 0; x <= W; x += 30) c.lineTo(x, hz - amp * (.5 + .5 * Math.abs(Math.sin(x * .006 * f + k * 3))) * (.55 + .45 * Math.sin(x * .0023 + k))); c.lineTo(W, hz + 10); c.closePath(); c.fill(); });
    c.fillStyle = grad(c, 0, hz, 0, H, [[0, K.suelo[0]], [1, K.suelo[1]]]); c.fillRect(0, hz, W, H - hz + 2);
    glow(c, sx, hz + 40, 700, 'rgba(255,170,90,A)', tipo === 'noche' ? .05 : .16);
    for (let i = 0; i < 46; i++) { const x = hash(i * 1.9) * W, y = hz + 30 + hash(i * 4.4) * (H - hz - 40), s = 8 + (y - hz) * .035; c.strokeStyle = 'rgba(' + (i % 3 ? '70,50,32' : '20,14,8') + ',.7)'; c.lineWidth = 3; c.beginPath(); c.moveTo(x, y); c.lineTo(x - s * .5, y - s); c.moveTo(x, y); c.lineTo(x + s * .3, y - s * 1.1); c.stroke(); }   // matitas de hierba
    for (let i = 0; i < 24; i++) { c.fillStyle = 'rgba(' + (i % 2 ? '60,48,36' : '40,30,20') + ',.8)'; c.beginPath(); c.ellipse(hash(i * 6.2) * W, hz + 60 + hash(i * 2.2) * (H - hz - 80), 10 + hash(i) * 12, 5 + hash(i + 2) * 5, 0, 0, TAU); c.fill(); }   // piedritas
    if (tipo === 'tormenta') {   // lluvia en líneas diagonales y rayo en zigzag con flash
      c.strokeStyle = 'rgba(200,210,235,.32)'; c.lineWidth = 2; c.beginPath(); for (let i = 0; i < 150; i++) { const sp = 1500 + hash(i) * 900, x = ((hash(i * 2.7) * (W + 600) - t * sp * .22) % (W + 600) + W + 600) % (W + 600) - 200, y = ((hash(i * 5.1) * H + t * sp) % (H + 200)) - 100; c.moveTo(x, y); c.lineTo(x - 22, y + 70); } c.stroke();
      const ciclo = Math.floor(t / 6.5), fase = t - ciclo * 6.5, fl = fase > 3 && fase < 3.35 ? 1 - (fase - 3) / .35 : 0;
      if (fl > 0) { c.fillStyle = 'rgba(230,225,255,' + fl * .35 + ')'; c.fillRect(0, 0, W, H); c.strokeStyle = 'rgba(235,230,255,' + fl + ')'; c.lineWidth = 7; c.beginPath(); let x = W * (.2 + hash(ciclo) * .6), y = 0; c.moveTo(x, y); while (y < hz * .75) { x += (hash(y + ciclo) - .5) * 120; y += 70 + hash(x) * 60; c.lineTo(x, y); } c.stroke(); }
    }
    return { hz, sx, sy, lado };
  }

  /* ---------------- SILUETAS (casi negras, de perfil, borde de luz dorado del lado del sol, bastón dorado más alto que ellos) ---------------- */
  function persona(c, x, yb, esc, t, o = {}) {
    const dir = o.lado || 1, tipo = o.tipo || 'anciano', bril = o.brillo || 0, camina = o.camina ? Math.abs(Math.sin(t * 4)) * 7 : 0, resp = 1 + .006 * Math.sin(t * 2 + (o.fase || 0));
    c.save(); c.translate(x + (o.camina ? Math.sin(t * 2) * 3 : 0), yb - camina); c.scale(esc * dir, esc * resp); c.scale(dir, 1);   // dir se aplica abajo con rimDir; el cuerpo no se espeja
    const rimLine = (f) => { c.strokeStyle = ORO; c.lineWidth = 3.6; c.lineCap = 'round'; c.shadowColor = 'rgba(232,178,90,.8)'; c.shadowBlur = 10; f(); c.stroke(); c.shadowBlur = 0; };
    const D = dir;   // lado del sol: borde dorado, cara y barba hacia ahí
    if (tipo === 'anciano') {
      c.fillStyle = grad(c, -128, 0, 128, 0, D > 0 ? [[0, '#201710'], [.55, OSC], [1, '#3e2e20']] : [[0, '#3e2e20'], [.45, OSC], [1, '#201710']]);
      c.beginPath(); c.moveTo(-22, -548); c.quadraticCurveTo(0, -576, 22, -548); c.bezierCurveTo(60, -540, 68, -490, 54, -452); c.bezierCurveTo(88, -380, 120, -200, 130, 0); c.quadraticCurveTo(0, 16, -130, 0); c.bezierCurveTo(-120, -200, -88, -380, -54, -452); c.bezierCurveTo(-68, -490, -60, -540, -22, -548); c.closePath(); c.fill();
      c.strokeStyle = 'rgba(0,0,0,.35)'; c.lineWidth = 3; for (let i = -3; i <= 3; i++) { c.beginPath(); c.moveTo(i * 14, -400); c.quadraticCurveTo(i * 24, -200, i * 36, -4); c.stroke(); }   // pliegues verticales
      c.fillStyle = '#f2ead8'; c.beginPath(); c.moveTo(D * 22, -500); c.quadraticCurveTo(D * 52, -496, D * 46, -450); c.quadraticCurveTo(D * 30, -418, D * 16, -450); c.closePath(); c.fill();   // barba blanca
      rimLine(() => { c.beginPath(); c.moveTo(D * 24, -552); c.bezierCurveTo(D * 66, -546, D * 72, -494, D * 56, -452); c.bezierCurveTo(D * 90, -380, D * 122, -200, D * 130, -2); });
    } else if (tipo === 'jesus') {
      c.fillStyle = grad(c, -90, 0, 90, 0, [[0, '#241a12'], [.5, OSC], [1, '#3a2c20']]); glow(c, 0, -500, 150, 'rgba(255,214,140,A)', .26 + .1 * Math.sin(t * 2));
      c.fillStyle = grad(c, -90, 0, 90, 0, [[0, '#241a12'], [.5, OSC], [1, '#3a2c20']]);
      c.beginPath(); c.moveTo(-30, -520); c.bezierCurveTo(-60, -500, -66, -450, -52, -420); c.bezierCurveTo(-70, -300, -84, -120, -88, 0); c.quadraticCurveTo(0, 12, 88, 0); c.bezierCurveTo(84, -120, 70, -300, 52, -420); c.bezierCurveTo(66, -450, 60, -500, 30, -520); c.bezierCurveTo(20, -566, -20, -566, -30, -520); c.closePath(); c.fill();
      c.beginPath(); c.arc(0, -502, 40, 0, TAU); c.fill();
      rimLine(() => { c.beginPath(); c.arc(0, -502, 42, -1.3, .5 * (D > 0 ? 1 : 0) + .4); }); rimLine(() => { c.beginPath(); c.moveTo(D * 52, -420); c.bezierCurveTo(D * 70, -300, D * 84, -120, D * 88, -2); });
    } else {   // joven: túnica corta, más delgado
      c.fillStyle = OSC; c.fillRect(-26, -210, 20, 210); c.fillRect(8, -210, 20, 210);
      c.fillStyle = grad(c, -64, 0, 64, 0, [[0, '#201710'], [.5, OSC], [1, '#3e2e20']]); c.beginPath(); c.moveTo(-34, -400); c.quadraticCurveTo(0, -418, 34, -400); c.lineTo(62, -190); c.quadraticCurveTo(0, -178, -62, -190); c.closePath(); c.fill();
      c.beginPath(); c.arc(0, -452, 36, 0, TAU); c.fill(); c.beginPath(); c.arc(-6, -486, 24, 0, TAU); c.fill();
      rimLine(() => { c.beginPath(); c.arc(0, -452, 38, -1.2, .4); }); rimLine(() => { c.beginPath(); c.moveTo(D * 34, -400); c.lineTo(D * 62, -192); });
    }
    if (tipo !== 'jesus') {   // bastón de pastor dorado, más alto que la figura
      const bx = D * (tipo === 'joven' ? 70 : 96), alto = tipo === 'joven' ? 560 : 650; c.strokeStyle = ORO; c.lineWidth = 8; c.lineCap = 'round'; c.shadowColor = 'rgba(240,200,100,' + (.4 + .6 * bril) + ')'; c.shadowBlur = 8 + 30 * bril;
      c.beginPath(); c.moveTo(bx, 0); c.lineTo(bx, -alto); c.arc(bx - D * 20, -alto, 20, 0, D > 0 ? -Math.PI * 1.1 : Math.PI * 1.1 + Math.PI, D > 0); c.stroke(); c.shadowBlur = 0;
    }
    if (o.martillo) { const a = Math.sin(t * 7) * .7; c.save(); c.translate(D * 70, -330); c.rotate(-.9 - a); c.strokeStyle = '#5a4030'; c.lineWidth = 8; c.beginPath(); c.moveTo(0, 0); c.lineTo(0, -110); c.stroke(); c.fillStyle = '#6a6270'; c.fillRect(-26, -128, 52, 22); c.restore(); }
    c.restore();
  }
  /* ---------------- OBJETOS ANCLA ---------------- */
  function arca(c, x, yb, esc, t, o = {}) {   // caja larga oscura con ventana amarilla encendida, en el horizonte a la derecha
    c.save(); c.translate(x, yb); c.scale(esc, esc);
    c.fillStyle = '#1c1410'; c.beginPath(); c.moveTo(-250, -70); c.lineTo(270, -80); c.lineTo(210, 14); c.lineTo(-190, 14); c.closePath(); c.fill();
    c.fillStyle = '#2a1e16'; c.fillRect(-190, -150, 360, 84); c.fillStyle = '#1c1410'; c.beginPath(); c.moveTo(-210, -150); c.lineTo(190, -152); c.lineTo(140, -196); c.lineTo(-160, -194); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(0,0,0,.4)'; c.lineWidth = 3; for (let i = -4; i <= 4; i++) { c.beginPath(); c.moveTo(i * 40, -64); c.lineTo(i * 36, 10); c.stroke(); }
    const pul = .85 + .15 * Math.sin(t * 3); if (o.encendida !== false) { glow(c, 40, -112, 130, 'rgba(255,208,100,A)', .55 * pul); c.fillStyle = '#ffd36a'; c.fillRect(22, -134, 36, 40); c.fillStyle = 'rgba(120,70,20,.6)'; c.fillRect(39, -134, 3, 40); }
    c.strokeStyle = 'rgba(232,178,90,.55)'; c.lineWidth = 3; c.beginPath(); c.moveTo(-250, -70); c.lineTo(270, -80); c.stroke();
    c.restore();
  }
  function lapida(c, x, yb, esc, t, o = {}) {   // lápida gris redondeada con nombre grabado que se ilumina en dorado
    c.save(); c.translate(x, yb); c.scale(esc, esc); c.fillStyle = grad(c, -90, 0, 90, 0, [[0, '#8a8490'], [1, '#524c58']]);
    c.beginPath(); c.moveTo(-90, 0); c.lineTo(-90, -230); c.quadraticCurveTo(0, -330, 90, -230); c.lineTo(90, 0); c.closePath(); c.fill();
    const l = clamp(o.luz == null ? 1 : o.luz); const col = l > 0 ? 'rgba(' + [lerp(60, 240, l), lerp(54, 190, l), lerp(64, 90, l)].map(Math.round).join(',') + ',1)' : '#3a3640';
    if (l > 0) { c.shadowColor = 'rgba(240,190,90,' + l + ')'; c.shadowBlur = 24 * l; } texto(c, o.texto || '', 0, -150, '700 30px ' + SERIF, col, 'center', 3); c.shadowBlur = 0; c.restore();
  }
  function ciudad(c, x, yb, w, t) {   // ciudad moderna con ventanas encendidas (comparación con el presente)
    for (let i = 0; i < 13; i++) { const bw = w / 13 * (.8 + hash(i) * .5), bh = 160 + hash(i * 3.1) * 420, bx = x + (i / 13 - .5) * w; c.fillStyle = i % 2 ? '#1c1a2a' : '#252238'; c.fillRect(bx, yb - bh, bw, bh);
      for (let yy = yb - bh + 20; yy < yb - 16; yy += 30) for (let xx = bx + 8; xx < bx + bw - 14; xx += 22) if (hash(i * 31 + yy * .13 + xx * .07) > .5) { c.fillStyle = hash(xx + yy) > .6 ? '#ffd88a' : 'rgba(255,200,120,.55)'; c.fillRect(xx, yy, 9, 14); } }
  }
  function camino(c, x0, x1, y, t, col = ORO) {   // línea dorada brillante en el suelo que corre entre personajes, con una chispa que viaja
    c.save(); c.strokeStyle = col; c.lineWidth = 6; c.lineCap = 'round'; c.shadowColor = col; c.shadowBlur = 18; c.beginPath(); c.moveTo(x0, y); c.lineTo(x1, y); c.stroke(); const p = (t * .5) % 1; c.fillStyle = '#fff6d0'; c.beginPath(); c.arc(lerp(x0, x1, p), y, 9, 0, TAU); c.fill(); c.restore();
  }

  /* ---------------- ELEMENTOS GRÁFICOS (cada uno recibe el tiempo local u = segundos desde que aparece) ---------------- */
  function nombre(c, W, u, o) {   // nombre en serif dorado mayúsculas, se escribe letra a letra con brillo; debajo, subtítulo pequeño
    const s = (o.texto || '').toUpperCase(), y = o.y || 330, n = Math.min(s.length, Math.floor(u / .07) + 1); let fs = 96; c.font = '700 ' + fs + 'px ' + SERIF; while (c.measureText(s).width + 6 * s.length > W - 100 && fs > 40) { fs -= 4; c.font = '700 ' + fs + 'px ' + SERIF; }
    c.save(); c.shadowColor = 'rgba(240,190,90,.75)'; c.shadowBlur = 22; texto(c, s.slice(0, n), W / 2, y, '700 ' + fs + 'px ' + SERIF, ORO2, 'center', 6); c.restore();
    if (o.sub) { c.globalAlpha = eOut(seg(u, s.length * .07, s.length * .07 + .4)) * .72; texto(c, o.sub, W / 2, y + 62, '500 34px ' + SANS, '#fff', 'center'); c.globalAlpha = 1; }
  }
  function cita(c, W, u, o) {   // píldora de cita: cápsula oscura con borde dorado fino y texto dorado
    const k = eBack(u / .45); if (k <= 0) return; c.save(); c.translate(W / 2, o.y || 1650); c.scale(k, k); c.font = '600 30px ' + SANS; const w = c.measureText(o.texto).width + 70, h = 62;
    rr(c, -w / 2, -h / 2, w, h, 31); c.fillStyle = 'rgba(20,16,24,.86)'; c.fill(); c.strokeStyle = 'rgba(232,178,90,.9)'; c.lineWidth = 2; c.stroke(); texto(c, o.texto, 0, 11, '600 30px ' + SANS, ORO2, 'center'); c.restore();
  }
  const COL = { amarillo: '#ffcf5a', naranja: '#ff9a45', azul: '#6ab8ff', verde: '#7ad69a', rojo: '#ff7a6a' };
  function contador(c, W, u, o) {   // cápsula con el número que cuenta hacia arriba + etiqueta pequeña («años»)
    const k = eBack(u / .4); if (k <= 0) return; const v = Math.round(lerp(o.desde || 0, o.valor, eOut(u / (o.dur || 1.6)))), col = COL[o.color] || o.color || COL.amarillo, num = String(v).replace(/\B(?=(\d{3})+(?!\d))/g, ' '), et = o.etiqueta || 'años';
    c.save(); c.translate(o.x != null ? o.x : W / 2, o.y || 640); c.scale(k, k); c.font = '800 96px ' + SANS; const w1 = c.measureText(num).width; c.font = '600 38px ' + SANS; const w2 = c.measureText(et).width, w = w1 + w2 + 90, h = 140;
    rr(c, -w / 2, -h / 2, w, h, 70); c.fillStyle = 'rgba(20,16,24,.86)'; c.fill(); texto(c, num, -w / 2 + 40, 34, '800 96px ' + SANS, col, 'left'); texto(c, et, -w / 2 + 40 + w1 + 14, 34, '600 38px ' + SANS, 'rgba(255,255,255,.85)', 'left'); c.restore();
  }
  function cadena(c, W, u, o) {   // chips «A → B → C» que se encienden uno a uno
    const it = o.items || [], y = o.y || 340; c.font = '600 34px ' + SANS; const ws = it.map(s => c.measureText(s).width + 50), tot = ws.reduce((a, b) => a + b, 0) + 56 * (it.length - 1); let x = W / 2 - tot / 2;
    it.forEach((s, i) => { const k = eBack((u - i * .55) / .4), on = u - i * .55 > 0; if (i > 0 && on) texto(c, '→', x - 28, y + 12, '700 34px ' + SANS, ORO, 'center'); if (k > 0) { c.save(); c.translate(x + ws[i] / 2, y); c.scale(k, k); rr(c, -ws[i] / 2, -30, ws[i], 60, 30); c.fillStyle = 'rgba(20,16,24,.86)'; c.fill(); c.strokeStyle = ORO; c.lineWidth = 2; c.stroke(); texto(c, s, 0, 12, '600 34px ' + SANS, '#fff', 'center'); c.restore(); } x += ws[i] + 56; });
  }
  function suma(c, W, u, o) {   // panel translúcido con barra segmentada que se llena, números debajo y el total arriba; luego barra crema con extremos punteados
    const k = eOut(u / .5); if (k <= 0) return; const P = o.partes || [], tot = P.reduce((a, b) => a + b, 0), y0 = o.y || 470, x0 = 110, bw = W - 220, cols = [COL.amarillo, COL.naranja, COL.azul, COL.verde];
    c.save(); c.globalAlpha = k; rr(c, 70, y0 - 30, W - 140, 330, 36); c.fillStyle = 'rgba(14,12,22,.62)'; c.fill(); c.strokeStyle = 'rgba(232,178,90,.35)'; c.lineWidth = 2; c.stroke();
    const llena = seg(u, .5, .5 + P.length * .9); let acc = 0, mostrado = Math.round(tot * eOut(llena));
    P.forEach((p, i) => { const a0 = acc / tot, a1 = (acc + p) / tot, f = clamp((llena * P.length - i)); c.fillStyle = cols[i % cols.length]; rr(c, x0 + bw * a0, y0 + 80, Math.max(2, bw * (a1 - a0) * f - 6), 56, 14); c.fill();
      texto(c, (i ? '+ ' : '') + p, x0 + bw * (a0 + a1) / 2, y0 + 190, '700 36px ' + SANS, cols[i % cols.length], 'center'); acc += p; });
    const w = 270, ty = y0 + 20; rr(c, W / 2 - w / 2, ty - 52, w, 70, 35); c.fillStyle = 'rgba(20,16,24,.9)'; c.fill(); texto(c, (o.total ? Math.round(o.total * eOut(llena)) : mostrado) + ' ' + (o.etiqueta || 'años'), W / 2, ty - 2, '800 40px ' + SANS, '#fff', 'center');
    if (o.comparar) { const v = eOut(seg(u, .5 + P.length * .9 + .4, .5 + P.length * .9 + 1.4)); c.fillStyle = '#f2e4c0'; rr(c, x0, y0 + 230, bw * v, 36, 12); c.fill(); if (v > .98) { c.setLineDash([6, 6]); c.strokeStyle = ORO; c.beginPath(); c.moveTo(x0, y0 + 215); c.lineTo(x0, y0 + 290); c.moveTo(x0 + bw, y0 + 215); c.lineTo(x0 + bw, y0 + 290); c.stroke(); c.setLineDash([]); texto(c, o.comparar[0], x0, y0 + 312, '500 24px ' + SANS, 'rgba(255,255,255,.8)', 'left'); texto(c, o.comparar[1], x0 + bw, y0 + 312, '500 24px ' + SANS, 'rgba(255,255,255,.8)', 'right'); } }
    c.restore();
  }
  function lineaTiempo(c, W, u, o) {   // línea fina dorada con extremos y etiqueta en cápsula
    const k = eOut(u / .8), y = o.y || 1560, x0 = 120, x1 = lerp(x0, W - 120, k); c.save(); c.strokeStyle = ORO; c.lineWidth = 3; c.beginPath(); c.moveTo(x0, y); c.lineTo(x1, y); c.stroke();
    [[x0, o.desde], [W - 120, o.hasta]].forEach(([x, s], i) => { if (i && k < 1) return; c.fillStyle = ORO; c.beginPath(); c.arc(x, y, 9, 0, TAU); c.fill(); texto(c, s || '', x, y + 46, '600 28px ' + SANS, '#fff', 'center'); });
    if (o.etiqueta && k > .6) { const a = eOut((k - .6) / .4); c.globalAlpha = a; c.font = '700 32px ' + SANS; const w = c.measureText(o.etiqueta).width + 50; rr(c, W / 2 - w / 2, y - 80, w, 54, 27); c.fillStyle = 'rgba(20,16,24,.88)'; c.fill(); texto(c, o.etiqueta, W / 2, y - 43, '700 32px ' + SANS, ORO2, 'center'); } c.restore();
  }
  function citaOro(c, W, u, o) {   // cita larga en dorado, centrada, con brillo; se escribe línea por línea
    const L = o.lineas || [o.texto || ''], y0 = o.y || 560; c.save(); c.shadowColor = 'rgba(240,190,90,.7)'; c.shadowBlur = 20; L.forEach((s, i) => { c.globalAlpha = eOut((u - i * .5) / .6); texto(c, s, W / 2, y0 + i * 62, '600 italic 46px ' + SERIF, ORO2, 'center'); }); c.restore();
  }
  function tarjetaCTA(c, W, H, u, o) {   // cierre con CTA (solo si el ajuste está activo): tarjeta de perfil con botón «Seguir» → «Siguiendo»
    const k = eOut(u / .6); if (k <= 0) return; c.save(); c.globalAlpha = k; c.translate(0, (1 - k) * 80); rr(c, 90, H - 330, W - 180, 150, 40); c.fillStyle = 'rgba(14,12,22,.88)'; c.fill(); c.strokeStyle = 'rgba(232,178,90,.5)'; c.stroke();
    c.fillStyle = grad(c, 130, H - 310, 230, H - 210, [[0, ORO2], [1, '#a86a30']]); c.beginPath(); c.arc(170, H - 255, 46, 0, TAU); c.fill(); texto(c, o.nombre || '@canal', 240, H - 262, '700 34px ' + SANS, '#fff', 'left'); texto(c, o.sub || 'Datos bíblicos exactos', 240, H - 222, '500 26px ' + SANS, 'rgba(255,255,255,.65)', 'left');
    const sig = u > 2.2; rr(c, W - 330, H - 290, 200, 66, 33); c.fillStyle = sig ? 'rgba(255,255,255,.14)' : '#4a7dff'; c.fill(); texto(c, sig ? 'Siguiendo' : 'Seguir', W - 230, H - 247, '700 30px ' + SANS, '#fff', 'center'); c.restore();
  }

  /* ---------------- SUBTÍTULO palabra por palabra (arriba, top≈190, máx. 3 palabras; dichas en gris 55 %, actual blanca en negrita; palabras clave con caja azul de selección) ---------------- */
  function subtitulos(c, W, t, grupos, caja) {
    let g = null; for (const x of grupos) if (t >= x.t0 && t < x.t1) { g = x; break; } if (!g) return;
    c.save(); c.textBaseline = 'alphabetic'; const fs = 46, y = 214; const ws = g.p.map((w, i) => { c.font = (t >= w.t0 && t < w.t1 ? '700 ' : '600 ') + fs + 'px ' + SANS; return c.measureText(w.w).width; }), esp = 16, tot = ws.reduce((a, b) => a + b, 0) + esp * (g.p.length - 1); let x = W / 2 - tot / 2;
    g.p.forEach((w, i) => { const act = t >= w.t0 && t < w.t1, dicha = t >= w.t1;
      if (w.clave && caja && t >= w.t0 - .05) { const a = eOut((t - w.t0) / .18), pad = 14; c.globalAlpha = a; c.fillStyle = 'rgba(74,125,255,.22)'; c.fillRect(x - pad, y - fs + 4, ws[i] + 2 * pad, fs + 18); c.strokeStyle = '#4a7dff'; c.lineWidth = 2; c.strokeRect(x - pad, y - fs + 4, ws[i] + 2 * pad, fs + 18); c.fillStyle = '#fff'; c.strokeStyle = '#4a7dff';
        [[x - pad, y - fs + 4], [x + ws[i] + pad, y + 18]].forEach(([hx, hy]) => { c.beginPath(); c.arc(hx, hy, 7, 0, TAU); c.fill(); c.stroke(); }); c.globalAlpha = 1; }
      c.font = (act ? '700 ' : '600 ') + fs + 'px ' + SANS; c.fillStyle = dicha ? 'rgba(255,255,255,.55)' : '#fff'; c.shadowColor = 'rgba(0,0,0,.6)'; c.shadowBlur = 8; c.textAlign = 'left'; c.fillText(w.w, x, y); c.shadowBlur = 0; x += ws[i] + esp; });
    c.restore();
  }
  function grano(c, W, H, t, k) {   // grano finísimo: ruido pre-dibujado que salta de sitio cada fotograma
    if (!k) return; if (!grano.cv) { const n = document.createElement('canvas'); n.width = 270; n.height = 480; const x = n.getContext('2d'), d = x.createImageData(270, 480); for (let i = 0; i < d.data.length; i += 4) { const v = hash(i * .37) * 255; d.data[i] = d.data[i + 1] = d.data[i + 2] = v; d.data[i + 3] = 255; } x.putImageData(d, 0, 0); grano.cv = n; }
    c.save(); c.globalAlpha = .045 * k; c.globalCompositeOperation = 'overlay'; const f = Math.floor(t * 24); c.drawImage(grano.cv, -(hash(f) * 60) | 0, -(hash(f + 7) * 60) | 0, W + 60, H + 60); c.restore();
  }
  return { cielo, persona, arca, lapida, ciudad, camino, nombre, cita, contador, cadena, suma, lineaTiempo, citaOro, tarjetaCTA, subtitulos, grano, clamp, lerp, seg, eOut, eIO, eBack, hash, glow, HZ, SANS, SERIF, ORO };
})();
