"""IDEAS del plugin «religion» (reels bíblicos «¿Sabías que…?»). El panel pide ideas con mas_ideas(formato, n, usados) y ideas_de(texto, formato) (pedido libre del usuario).
Cada idea: {"formato", "titulo", "desc", "modo"}. «modo» = tipo de dato (genealogia, numeros, medidas, milagro, ensenanza). Cada tema trae: título-gancho (≤ 14 palabras), el dato o giro, las citas que lo sostienen
(libro capítulo:versículo, COMPROBADAS) y la imagen ancla (personaje + escenario que se repite). Regla del plugin: solo datos bíblicos exactos; lo discutido se dice «hay quien traduce…» / «muchos creen…»."""
import random, time
TEMAS = [  # (título-gancho, dato/giro, citas, imagen ancla, modo)
    ("¿Sabías que el hombre que más vivió en la Biblia murió el año del diluvio?", "Matusalén vivió 969 años; 187 (nace Lamec) + 182 (nace Noé) + 600 (diluvio) = 969, exactamente.", "Génesis 5:25, 5:28, 5:27, 7:6", "El anciano de manto con bastón y el arca encendida en el horizonte", "genealogia"),
    ("¿Sabías que hubo un hombre en la Biblia que nunca murió?", "Enoc caminó con Dios y desapareció porque Dios se lo llevó; tenía 365 años y era el padre de Matusalén.", "Génesis 5:21-24; Hebreos 11:5", "Silueta de Enoc caminando hacia la luz al atardecer", "genealogia"),
    ("¿Sabías que el padre de Noé vivió exactamente 777 años?", "Lamec tenía 182 años cuando nació Noé y vivió 595 más: 182 + 595 = 777.", "Génesis 5:28-31", "Lamec y el niño Noé bajo un cielo naranja", "numeros"),
    ("¿Sabías que Moisés vivió tres vidas de cuarenta años?", "40 años en el palacio de Egipto, 40 en Madián y 40 guiando al pueblo; murió a los 120 con la vista intacta.", "Hechos 7:23, 7:30; Deuteronomio 34:7", "El anciano con su bastón frente a una montaña violeta", "numeros"),
    ("¿Sabías que el número 40 aparece una y otra vez en la Biblia?", "40 días de lluvia, 40 días de Moisés en el Sinaí, 40 días de Elías hacia el Horeb y 40 días de Jesús en el desierto.", "Génesis 7:12; Éxodo 24:18; 1 Reyes 19:8; Mateo 4:2", "Cuatro siluetas en cuatro cielos distintos", "numeros"),
    ("¿Sabías que el arca de Noé era casi tan larga como un campo de fútbol?", "300 codos de largo, 50 de ancho y 30 de alto: más de 130 metros según la medida común del codo (≈ 44 cm).", "Génesis 6:15", "El arca en construcción y Noé martillando", "medidas"),
    ("¿Sabías que Goliat medía casi tres metros, según el texto?", "«Seis codos y un palmo» (≈ 2,9 m); hay manuscritos antiguos que dicen «cuatro codos y un palmo» (≈ 2 m).", "1 Samuel 17:4", "David pequeño frente a una silueta gigante", "medidas"),
    ("¿Sabías que Jesús dijo que perdones setenta veces siete?", "Pedro preguntó si bastaba perdonar siete veces; la cifra evoca a Lamec y su venganza de setenta y siete (Génesis 4:24): Jesús la invierte.", "Mateo 18:21-22; Génesis 4:24", "Pedro y Jesús frente a frente al atardecer", "ensenanza"),
    ("¿Sabías que Jonás estuvo tres días y tres noches dentro del pez?", "Jesús lo usó como señal de su propia resurrección.", "Jonás 1:17; Mateo 12:40", "Una barca pequeña bajo un cielo de tormenta", "milagro"),
    ("¿Sabías que el sol se detuvo un día entero en la Biblia?", "Josué pidió que el sol y la luna se detuvieran durante la batalla; el texto dice que no hubo un día igual.", "Josué 10:12-14", "Siluetas de guerreros bajo un sol enorme y pálido", "milagro"),
    ("¿Sabías que un rey pidió más vida y la sombra retrocedió diez grados?", "Dios le añadió quince años a Ezequías y la sombra del reloj de sol retrocedió.", "2 Reyes 20:6, 20:9-11", "Un anciano frente a una escalera de sombra y luz", "milagro"),
    ("¿Sabías que Gedeón venció a un ejército enorme con solo 300 hombres?", "De 32.000 soldados quedaron 10.000 y luego 300: Dios redujo el ejército para que no presumieran.", "Jueces 7:3, 7:6-7", "Tres siluetas con antorchas y un campamento dormido", "numeros"),
    ("¿Sabías que Jericó cayó después de siete vueltas en siete días?", "Seis días una vuelta; el séptimo, siete vueltas con siete sacerdotes y siete trompetas.", "Josué 6:3-4, 6:15", "Las murallas de Jericó al amanecer y las trompetas", "numeros"),
    ("¿Sabías que los discípulos sacaron exactamente 153 peces y la red no se rompió?", "Juan cuenta el número exacto: ciento cincuenta y tres grandes peces.", "Juan 21:11", "La orilla del lago al amanecer y una red llena", "numeros"),
    ("¿Sabías que Salomón recibía 666 talentos de oro cada año?", "Un detalle que casi nadie nota: el peso del oro que le llegaba cada año era de 666 talentos.", "1 Reyes 10:14", "El rey en silueta frente a un tesoro encendido", "numeros"),
    ("¿Sabías que Jesús tenía doce años cuando lo buscaron tres días?", "José y María lo hallaron en el templo, sentado entre los maestros, oyéndolos y preguntándoles.", "Lucas 2:42, 2:46", "El niño en silueta y las columnas del templo", "ensenanza"),
]
def _idea(t, fm):
    a, b, c, d, md = t
    return {"formato": fm, "titulo": a, "desc": "Dato: %s Citas: %s. Imagen ancla: %s. (Verificar cada cifra y versículo antes de escribir el guion.)" % (b, c, d), "modo": md}
def mas_ideas(fm, n=10, usados=()):
    usados = set(usados); pool = [t for t in TEMAS if t[0] not in usados]; random.Random(int(time.time())).shuffle(pool)
    out = [_idea(t, "short") for t in pool[:max(1, n)]]
    if len(out) < n:   # si ya se usaron casi todos, ofrece los usados con otro enfoque (siempre se puede pedir otro lote)
        rest = [t for t in TEMAS if t not in pool[:n]]; random.Random(7).shuffle(rest)
        for t in rest[:n - len(out)]:
            i = _idea(t, "short"); i["titulo"] = t[0] + " (otro enfoque)"; i["desc"] = "Mismo dato con otro enfoque (otra imagen ancla y otro ritmo). " + i["desc"]; out.append(i)
    return out
def ideas_de(texto, fm):   # pedido libre: «haz un video sobre X» -> 6 formas de contarlo en el estilo del plugin
    t = (texto or "").strip().rstrip(".?!"); t = t[:1].lower() + t[1:] if t else "este pasaje"; r = random.Random(sum(map(ord, t)) + len(t))
    base = [("¿Sabías que %s tiene un dato que casi nadie nota?" % t, "El dato que sorprende sobre %s, con sus números y su cita." % t, "genealogia"),
            ("¿Sabías que lo que dice la Biblia sobre %s se puede comprobar con una suma?" % t, "Una cadena de cifras con cita que da un resultado exacto.", "numeros"),
            ("¿Sabías que %s cambia de sentido según cómo se traduzca?" % t, "Qué dice el texto, qué traducen otras versiones y qué creen muchos.", "ensenanza"),
            ("¿Sabías que %s ya estaba anunciado antes de pasar?" % t, "La profecía, la cita y el momento en que se cumple.", "milagro"),
            ("¿Sabías que %s mide más de lo que imaginas?" % t, "Las medidas del texto convertidas a metros, para que te hagas una idea.", "medidas"),
            ("¿Sabías que %s esconde una enseñanza sobre la paciencia de Dios?" % t, "La lectura espiritual con su versículo.", "ensenanza")]
    r.shuffle(base); return [{"formato": "short", "titulo": a, "desc": b + " (Verificar cada cifra y versículo antes de escribir el guion.)", "modo": c} for a, b, c in base]
