# Referencia del estilo «Religión (Matusalén)»

Este plugin sale de la skill «religion» del usuario (reels bíblicos 9:16 de 60–90 s estilo «¿Sabías que…?», ilustración vectorial plana animada en código). Qué se conservó y qué cambió al volverla plugin del DevIAs Panel:

| Skill original | En el plugin |
|---|---|
| Flujo: 4 temas → el usuario elige → guion → voz → video completo | Igual, dentro del panel: ideas (`ideas_religion.py`) → ficha → borrador mudo → «Estoy conforme» → voz → unión |
| Voz en ai84.pro (ElevenLabs v3, voz 4ClPfGRNxnfy7Zzp4OId) | **Se quita:** la voz la genera Voice Studio desde el panel |
| Video en Remotion (React/SVG, node, whisper.cpp para subtítulos) | **Se reemplaza** por un motor propio en canvas 2D (`motor/religion.js`); los tiempos de cada palabra salen del guion del panel (no hace falta Whisper) |
| Componentes (Sky sunset/storm/night/divine, Elder, JesusSil, ArkSide, Tomb, CountPill, NameTitle, Cite…) | Equivalentes: `cielo`, `persona (anciano/joven/jesus)`, `arca`, `lapida`, `contador`, `nombre`, `cita`, `cadena`, `suma`, `linea_tiempo`, `cita_oro`, `tarjetaCTA` |
| Referencias de estilo: reel IG Dfeos7QMSth (Matusalén y el diluvio, 66,8 s) y reel DfdL6dbsB0l (perdón 70×7) | Mismas: son la guía visual del estilo (no se copian sus imágenes) |
| Sonido sintetizado (pad, lluvia, truenos, pop, whoosh, sparkle, ding) | Se anuncia con `cues` del video para que la mezcla del panel lo use; la voz va al frente |
| CTA «Si crees en Dios, sígueme y comparte» solo si el usuario lo quiere | Ajuste «Tarjeta de seguir al final» (apagado por defecto) |

## Reglas que se mantienen de la skill
- Cada tema = un dato bíblico sorprendente y verificable con números o una coincidencia; formato por tema: título-gancho (≤ 14 palabras), dato/giro, citas comprobadas, imagen ancla. Se evitan los temas ya hechos.
- Guion de 150–185 palabras (60–75 s), los 9 bloques, tono solemne-informativo, segunda persona puntual; solo datos exactos («hay quien traduce…» / «muchos creen…» si se discute); cada frase debe poder dibujarse.
- Texto limpio sin acotaciones; debajo, lista de palabras clave (caja azul) y citas con el segundo aproximado.
- Visual: horizonte en y≈1410, cielos, siluetas con borde dorado, arca con ventana encendida siempre a la derecha, composición con el personaje en el tercio medio-inferior, el superior para subtítulo y nombre, cambio de toma cada 4–8 s, ninguna toma quieta, cierre circular.
