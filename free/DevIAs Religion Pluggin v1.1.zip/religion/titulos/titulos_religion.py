"""TÍTULOS, DESCRIPCIÓN, HASHTAGS Y ETIQUETAS del plugin «religion» (pestaña Publicar). Datos: bloque `seo` de proyecto.json:
{tipo, sujeto, hecho, pregunta, gancho, momentos:[...], datos:[...], hashtags:[...], tags_tema:[...]}.
Reglas: gancho primero (curiosidad con número o cita), 30-75 caracteres, hablar del dato bíblico del video y citar libro y versículo, 5 hashtags (#Shorts primero), etiquetas ≤ 500 caracteres.
20 núcleos × 12 colas × emojis: siempre se puede pedir otro lote de 100 (error real de otro plugin: con pocas plantillas el 2.º lote salía vacío)."""
import random, hashlib, re
EMO = ["📖", "✝️", "🕊️", "✨", "🙏", "🔥", "🌅", "📜"]
CORES = ["¿Sabías que {S}?", "{S}: el dato que casi nadie nota", "{S}, según la Biblia", "Lo que dice la Biblia sobre {S}", "{S}: la suma que lo cambia todo", "El número oculto de {S}", "{S} y su cita exacta",
         "Nadie te contó esto de {S}", "{S}: ¿casualidad o diseño?", "{S} en el Génesis y más", "Mira lo que pasa con {S}", "{S}: los números no mienten", "El detalle de {S} que sorprende",
         "{S} explicado en un minuto", "¿Lo habías notado? {S}", "{S}: lo que la Biblia dice y se pasa por alto", "Así lo cuenta la Biblia: {S}", "{S}: una cifra, una cita, una enseñanza", "Antes de que lo olvides: {S}", "{S}: el dato bíblico del día"]
COLAS = ["", "Con cita bíblica", "Datos exactos", "Mira la suma", "Te sorprenderá", "Con números reales", "En menos de un minuto", "Biblia explicada", "Para pensar", "Curiosidad bíblica", "Texto y cita", "Datos de la Biblia"]
TH = [((c + (" · " + t if t else "")).strip() + " {E}") for c in CORES for t in COLAS]
def _slug(s): return re.sub(r"[^A-Za-z0-9ÁÉÍÓÚÑáéíóúñ]", "", s.title())
def _tags(f):
    S = (f.get("sujeto") or "").lower(); base = [S, "biblia", "datos bíblicos", "curiosidades de la biblia", "¿sabías que?", "fe", "dios", "jesús", "génesis", "antiguo testamento", "reflexión cristiana", "estudio bíblico", "versículos", "shorts"] + list(f.get("tags_tema") or [])
    out, n, vistos = [], 0, set()
    for x in base:
        x = re.sub(r"\s+", " ", str(x).strip())
        if not x or x.lower() in vistos or len(x) > 60 or n + len(x) + 1 > 500: continue
        vistos.add(x.lower()); out.append(x); n += len(x) + 1
    return out
def _score(t, f):
    s = 55 + (12 if 30 <= len(t) <= 75 else 0) + (8 if "¿" in t or any(w in t.lower() for w in ("nadie", "sorprende", "suma", "exact")) else 0) + (6 if (f.get("sujeto", "").lower() in t.lower()) else 0) + (6 if re.search(r"\d", t) else 0)
    return min(99, s)
def generar(pid, f, lote, usados=(), largo=False):
    rnd = random.Random(int(hashlib.md5(("%s-%d-rel1" % (pid, lote)).encode()).hexdigest()[:8], 16)); S = f.get("sujeto") or "este pasaje"; mom = f.get("momentos") or ["el dato", "la cita", "la enseñanza"]
    datos = f.get("datos") or []; cits = [m.group(0) for d in datos for m in [re.search(r"(?:\d\s)?[A-Za-zÁÉÍÓÚÑáéíóúñ]+\s\d+:\d+(?:-\d+)?", d)] if m]
    out, vistos, intentos, uso = [], set(usados), 0, {}
    while len(out) < 100 and intentos < 40000:
        intentos += 1; tpl = rnd.choice(TH); t = tpl.format(S=S, E=rnd.choice(EMO)).replace("  ", " ").strip(); t = re.sub(r"\s+([?!…])", r"\1", t); t = t[:1].upper() + t[1:]
        lim = 75 if intentos < 12000 else 95
        if t in vistos or len(t) > lim or uso.get(tpl, 0) >= 1 + intentos // 4000: continue
        uso[tpl] = uso.get(tpl, 0) + 1; vistos.add(t); m3 = rnd.sample(mom, min(3, len(mom))); dd = datos[:]; rnd.shuffle(dd)
        l1 = rnd.choice(["%s Un dato bíblico con sus números y su cita exacta." % (f.get("hecho") or S), "Un reel bíblico: %s." % (f.get("hecho") or S)])
        l2 = "En este video: " + ", ".join(m3) + "."; l3 = " ".join("• %s" % z for z in dd[:3]); l4 = ("📖 " + ", ".join(cits[:4])) if cits else ""
        cta = rnd.choice(["💬 ¿Lo habías notado? Cuéntamelo en los comentarios.", "💬 ¿Qué otro dato de la Biblia quieres que explique?"])
        hs = ["#Shorts", "#" + _slug(S)[:28], "#Biblia", "#Fe", "#Jesus"]
        desc = "\n".join([l1, l2] + ([l3] if l3 else []) + ([l4] if l4 else []) + ["", cta, "", " ".join(hs)])
        out.append({"titulo": t, "descripcion": desc, "etiquetas": _tags(f), "score": _score(t, f), "motivo": ["curiosidad", "fe"], "largo": len(t), "hook_3s": rnd.choice(["¿Sabías que…?", "Mira la suma", "Los números no mienten"]),
                    "comentario_fijado": "¿Lo habías notado? Cuéntame en los comentarios.", "hashtags": hs})
    out.sort(key=lambda o: -o["score"]); return out[:100]
